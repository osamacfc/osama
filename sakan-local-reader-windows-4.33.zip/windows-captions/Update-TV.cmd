@echo off
setlocal
set "ADB=%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe"
set "APK=%USERPROFILE%\Downloads\sakan-local-reader-4.33.apk"
if exist "%~dp0sakan-local-reader-4.33.apk" set "APK=%~dp0sakan-local-reader-4.33.apk"
if not exist "%APK%" (
 echo Download sakan-local-reader-4.33.apk to Downloads or put it beside this file.
 goto failed
)
"%ADB%" connect 192.168.8.28:5555 || goto failed
"%ADB%" -s 192.168.8.28:5555 install -r "%APK%" || goto failed
"%ADB%" -s 192.168.8.28:5555 shell am start -n com.osama.sakan/com.gathin.tvhome.MainActivity || goto failed
exit /b 0
:failed
pause
exit /b 1
