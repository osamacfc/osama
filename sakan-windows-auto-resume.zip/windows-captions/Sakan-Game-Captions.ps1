﻿#requires -Version 5.1
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
Add-Type -ReferencedAssemblies 'System.Drawing' -TypeDefinition @'
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text;
public static class SakanGameCapture {
    [StructLayout(LayoutKind.Sequential)]
    private struct Rect { public int Left, Top, Right, Bottom; }
    [StructLayout(LayoutKind.Sequential)]
    private struct Point { public int X, Y; }

    [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
    [DllImport("user32.dll")] static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
    public static void EnablePhysicalPixels() {
        try {
            if (SetThreadDpiAwarenessContext(new IntPtr(-4)) != IntPtr.Zero) return;
        } catch (EntryPointNotFoundException) {}
        SetProcessDPIAware();
    }
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr window, StringBuilder title, int capacity);
    public static bool IsRemotePlayTitle(IntPtr window) {
        var title = new StringBuilder(256);
        GetWindowText(window, title, title.Capacity);
        return string.Equals(title.ToString().Trim(), "PS Remote Play", StringComparison.OrdinalIgnoreCase);
    }
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr window, out int processId);
    public static int WindowOwner(IntPtr window) {
        int processId;
        GetWindowThreadProcessId(window, out processId);
        return processId;
    }
    [DllImport("user32.dll")] static extern bool IsIconic(IntPtr window);
    [DllImport("user32.dll")] static extern bool GetClientRect(IntPtr window, out Rect rect);
    [DllImport("user32.dll")] static extern bool ClientToScreen(IntPtr window, ref Point point);

    public static Rectangle ClientArea(IntPtr window) {
        if (window == IntPtr.Zero || IsIconic(window)) return Rectangle.Empty;
        Rect rect;
        var origin = new Point();
        if (!GetClientRect(window, out rect) || !ClientToScreen(window, ref origin)) return Rectangle.Empty;
        int width = rect.Right, height = rect.Bottom;
        if (width < 160 || height < 90) return Rectangle.Empty;
        return new Rectangle(origin.X, origin.Y, width, height);
    }

    public static Bitmap Snapshot(Rectangle area, Rectangle screen) {
        Rectangle visible = Rectangle.Intersect(area, screen);
        if (visible.Width == 0 || visible.Height == 0)
            throw new ArgumentException("The game window is outside the display.");
        var image = new Bitmap(area.Width, area.Height, PixelFormat.Format24bppRgb);
        try {
            using (var graphics = Graphics.FromImage(image)) {
                graphics.Clear(Color.Black);
                graphics.CopyFromScreen(visible.X, visible.Y, visible.X - area.X, visible.Y - area.Y,
                    visible.Size, CopyPixelOperation.SourceCopy);
            }
            return image;
        } catch {
            image.Dispose();
            throw;
        }
    }

    public static Rectangle MapSelection(Rectangle source, Size view, Rectangle selection) {
        selection = Rectangle.Intersect(selection, new Rectangle(System.Drawing.Point.Empty, view));
        if (selection.Width == 0 || selection.Height == 0) return Rectangle.Empty;
        return Rectangle.FromLTRB(
            source.X + (int)Math.Floor((double)selection.Left * source.Width / view.Width),
            source.Y + (int)Math.Floor((double)selection.Top * source.Height / view.Height),
            source.X + (int)Math.Ceiling((double)selection.Right * source.Width / view.Width),
            source.Y + (int)Math.Ceiling((double)selection.Bottom * source.Height / view.Height));
    }

    public static Rectangle RemapSelection(Rectangle original, Rectangle selection, Rectangle current) {
        if (selection == original) return current;
        Rectangle game = FitGameArea(original);
        if (game.Contains(selection)) {
            original = game;
            current = FitGameArea(current);
        }
        var relative = new Rectangle(selection.X - original.X, selection.Y - original.Y,
            selection.Width, selection.Height);
        return MapSelection(current, original.Size, relative);
    }

    static Rectangle FitGameArea(Rectangle client) {
        int width = Math.Min(client.Width, client.Height * 16 / 9);
        int height = Math.Min(client.Height, client.Width * 9 / 16);
        return new Rectangle(client.X + (client.Width - width) / 2,
            client.Y + (client.Height - height) / 2, width, height);
    }

    public sealed class Frame {
        public byte[] Upload { get; set; }
        public byte[] Preview { get; set; }
        public string Coordinates { get; set; }
    }

    public static bool IsNearlyBlack(Bitmap image) {
        using (var small = new Bitmap(image, 64, 36)) {
            for (int y = 0; y < small.Height; y++) {
                for (int x = 0; x < small.Width; x++) {
                    Color sample = small.GetPixel(x, y);
                    if (sample.R > 12 || sample.G > 12 || sample.B > 12) return false;
                }
            }
        }
        return true;
    }

    public static double PhoneScreenAngle(bool[,] light) {
        int height = light.GetLength(0), width = light.GetLength(1);
        if (width < 24 || height < width * 1.16) return 0;

        // Fit the upper and lower edges of the lit display across its middle.
        int count = 0;
        double sumX = 0, sumXX = 0, sumTop = 0, sumBottom = 0, sumXTop = 0, sumXBottom = 0;
        for (int x = width * 3 / 10; x < width * 7 / 10; x++) {
            int top = 0, bottom = height - 1;
            while (top + 2 < height && !(light[top, x] && light[top + 1, x] && light[top + 2, x])) top++;
            while (bottom >= 2 && !(light[bottom, x] && light[bottom - 1, x] && light[bottom - 2, x])) bottom--;
            if (top == 0 || bottom == height - 1 || bottom - top < height * .60) continue;
            count++;
            sumX += x;
            sumXX += x * x;
            sumTop += top;
            sumBottom += bottom;
            sumXTop += x * top;
            sumXBottom += x * bottom;
        }
        double variance = count * sumXX - sumX * sumX;
        if (count < width * .30 || variance == 0) return 0;
        double upperSlope = (count * sumXTop - sumX * sumTop) / variance;
        double lowerSlope = (count * sumXBottom - sumX * sumBottom) / variance;
        if (upperSlope * lowerSlope <= 0 || Math.Abs(upperSlope - lowerSlope) > .14) return 0;
        double angle = Math.Atan((upperSlope + lowerSlope) / 2) * 180 / Math.PI;
        return Math.Abs(angle) >= 1.5 && Math.Abs(angle) <= 16 ? angle : 0;
    }

    static byte[] EncodeSelection(Bitmap image, bool straightenPhone, Rectangle crop, Rectangle game,
            out string coordinates) {
        coordinates = FrameCoordinates(crop, game, image.Size, image.Size, 0);
        if (!straightenPhone || image.Height < image.Width * 1.16) return Encode(image, 1800);
        double angle;
        using (var sample = new Bitmap(image, Math.Max(1, image.Width * 160 / image.Height), 160)) {
            var light = new bool[sample.Height, sample.Width];
            for (int y = 0; y < sample.Height; y++) {
                for (int x = 0; x < sample.Width; x++) {
                    Color pixel = sample.GetPixel(x, y);
                    light[y, x] = Math.Min(pixel.R, Math.Min(pixel.G, pixel.B)) >= 155;
                }
            }
            angle = PhoneScreenAngle(light);
        }
        if (angle == 0) return Encode(image, 1800);
        double radians = Math.Abs(angle) * Math.PI / 180;
        int width = (int)Math.Ceiling(image.Width * Math.Cos(radians) + image.Height * Math.Sin(radians));
        int height = (int)Math.Ceiling(image.Height * Math.Cos(radians) + image.Width * Math.Sin(radians));
        coordinates = FrameCoordinates(crop, game, image.Size, new Size(width, height), angle);
        using (var level = new Bitmap(width, height, PixelFormat.Format24bppRgb)) {
            using (var graphics = Graphics.FromImage(level)) {
                graphics.Clear(Color.Black);
                graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                graphics.TranslateTransform(width / 2f, height / 2f);
                graphics.RotateTransform((float)-angle);
                graphics.DrawImage(image, -image.Width / 2f, -image.Height / 2f, image.Width, image.Height);
            }
            return Encode(level, 1800);
        }
    }

    public static string FrameCoordinates(Rectangle crop, Rectangle game, Size source, Size upload, double angle) {
        // Undo the rotation about the center of the crop before mapping to the 16:9 game image.
        double radians = angle * Math.PI / 180;
        double cos = Math.Cos(radians), sin = Math.Sin(radians);
        double scaleX = (double)crop.Width / source.Width / game.Width;
        double scaleY = (double)crop.Height / source.Height / game.Height;
        double xx = cos * upload.Width * scaleX, xy = -sin * upload.Height * scaleX;
        double yx = sin * upload.Width * scaleY, yy = cos * upload.Height * scaleY;
        double x = ((double)crop.Left - game.Left + crop.Width / 2.0) / game.Width;
        double y = ((double)crop.Top - game.Top + crop.Height / 2.0) / game.Height;
        return string.Format(CultureInfo.InvariantCulture, "{0:F8},{1:F8},{2:F8},{3:F8},{4:F8},{5:F8}",
            x - (xx + xy) / 2, xx, xy, y - (yx + yy) / 2, yx, yy);
    }

    public static Frame CaptureFrame(Rectangle area, Rectangle selection, bool straightenPhone, Rectangle screen) {
        Rectangle game = FitGameArea(area);
        bool whole = selection == area;
        if (whole) {
            area = game;
            selection = game;
        }
        var region = new Rectangle(selection.X - area.X, selection.Y - area.Y, selection.Width, selection.Height);
        using (var full = Snapshot(area, screen)) {
            if (IsNearlyBlack(full)) return new Frame { Preview = Encode(full, 1200) };
            if (whole) {
                byte[] upload = Encode(full, 1800);
                return new Frame { Upload = upload, Preview = upload, Coordinates = "0,1,0,0,0,1" };
            }
            double scale = Math.Max(1, Math.Min(2, 1800.0 / Math.Max(region.Width, region.Height)));
            Size size = new Size((int)(region.Width * scale), (int)(region.Height * scale));
            Rectangle output = new Rectangle(System.Drawing.Point.Empty, size);
            using (var selected = new Bitmap(size.Width, size.Height, PixelFormat.Format24bppRgb)) {
                using (var graphics = Graphics.FromImage(selected)) {
                    graphics.Clear(Color.Black);
                    graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    graphics.DrawImage(full, output, region, GraphicsUnit.Pixel);
                }
                string coordinates;
                byte[] upload = EncodeSelection(selected, straightenPhone, selection, game, out coordinates);
                using (var graphics = Graphics.FromImage(full))
                using (var border = new Pen(Color.Gold, Math.Max(2, full.Width / 500)))
                    graphics.DrawRectangle(border, region);
                return new Frame { Upload = upload, Preview = Encode(full, 1200), Coordinates = coordinates };
            }
        }
    }

    static byte[] Encode(Bitmap image, int limit) {
        double scale = Math.Min(1.0, (double)limit / Math.Max(image.Width, image.Height));
        using (var scaled = new Bitmap(image, (int)(image.Width * scale), (int)(image.Height * scale)))
        using (var stream = new MemoryStream())
        using (var encoder = new EncoderParameters(1)) {
            var codec = Array.Find(ImageCodecInfo.GetImageEncoders(), item => item.FormatID == ImageFormat.Jpeg.Guid);
            foreach (long quality in new long[] { 82, 62, 42 }) {
                stream.SetLength(0);
                encoder.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, quality);
                try {
                    scaled.Save(stream, codec, encoder);
                } finally {
                    encoder.Param[0].Dispose();
                    encoder.Param[0] = null;
                }
                if (stream.Length <= 590000) return stream.ToArray();
            }
            throw new InvalidOperationException("The game image is too large.");
        }
    }
}
'@
[SakanGameCapture]::EnablePhysicalPixels()
[System.Windows.Forms.Application]::SetUnhandledExceptionMode(
    [System.Windows.Forms.UnhandledExceptionMode]::ThrowException)

function Get-PrivateAddress([string]$address) {
    if ($address -notmatch '^\d{1,3}(?:\.\d{1,3}){3}$') { throw 'أدخل عنوان التلفزيون المحلي.' }
    [ipaddress]$ip = [ipaddress]::None
    if (-not [ipaddress]::TryParse($address, [ref]$ip) -or $address -ne $ip.ToString()) {
        throw 'أدخل عنوان التلفزيون المحلي.'
    }
    $number = $ip.GetAddressBytes()
    if ($number[0] -ne 10 -and
        -not ($number[0] -eq 172 -and $number[1] -ge 16 -and $number[1] -le 31) -and
        -not ($number[0] -eq 192 -and $number[1] -eq 168)) { throw 'استخدم عنوانًا من شبكة البيت.' }
    return $ip.ToString()
}

function Invoke-Sakan([string]$path, [hashtable]$body, [switch]$allowRejected) {
    $headers = @{}
    if ($path -ne '/pair') { $headers.Authorization = "Bearer $($script:token)" }
    $json = ConvertTo-Json -InputObject $body -Compress
    $reply = Invoke-RestMethod -Method Post -Uri "http://$($script:tvAddress):8787$path" -Headers $headers `
        -ContentType 'application/json' -Body ([Text.Encoding]::UTF8.GetBytes($json)) -TimeoutSec 3 -MaximumRedirection 0
    $script:rejectedRequests = 0
    if ($reply.ok -eq $false -and -not $allowRejected) { throw $reply.message }
    return $reply
}

function Submit-GameFrame([byte[]]$jpeg, [string]$language, [string]$font, [string]$size, [string]$tone, [bool]$focused, [string]$coordinates) {
    $headers = @{
        Authorization = "Bearer $($script:token)"
        'X-Sakan-Language' = $language
        'X-Sakan-Font' = $font
        'X-Sakan-Size' = $size
        'X-Sakan-Tone' = $tone
        'X-Sakan-Focus' = if ($focused) { 'selection' } else { 'screen' }
    }
    if ($coordinates) { $headers['X-Sakan-Coordinates'] = $coordinates }
    $reply = Invoke-RestMethod -Method Post -Uri "http://$($script:tvAddress):8787/game-frame" -Headers $headers `
        -ContentType 'image/jpeg' -Body $jpeg -TimeoutSec 4 -MaximumRedirection 0
    $script:rejectedRequests = 0
    if ($reply.ok -eq $false) { throw $reply.message }
    return $reply
}

$form = New-Object System.Windows.Forms.Form -Property @{
    Text = 'ترجمة اللعب · سكن'; StartPosition = 'CenterScreen'; Size = '460,591'
    FormBorderStyle = 'FixedDialog'; MaximizeBox = $false
}
$uiFont = New-Object System.Drawing.Font('Segoe UI', 10)
$form.Font = $uiFont
function New-Control($type, $text, $left, $top, $width, $height) {
    $control = New-Object "System.Windows.Forms.$type" -Property @{
        Text = $text; Left = $left; Top = $top; Width = $width; Height = $height
    }
    $form.Controls.Add($control)
    return $control
}
function New-Choice($label, $top, $choices, $index) {
    [void](New-Control Label $label 20 $top 135 25)
    $box = New-Control ComboBox '' 165 $top 230 26
    $box.DropDownStyle = 'DropDownList'
    $box.Items.AddRange($choices)
    $box.SelectedIndex = $index
    return $box
}

[void](New-Control Label 'عنوان التلفزيون' 20 20 135 25)
$addressInput = New-Control TextBox '192.168.8.28' 165 20 230 26
[void](New-Control Label 'رمز اللابتوب' 20 57 135 25)
$codeInput = New-Control TextBox '' 165 57 115 26
$codeInput.MaxLength = 6
$pairButton = New-Control Button 'ربط التلفزيون' 290 54 105 32
$languageInput = New-Choice 'لغة النص' 94 @('الإنجليزية', 'الإسبانية') 0
$fontInput = New-Choice 'أسلوب الخط' 130 @('عادي', 'عريض', 'مضغوط', 'تقليدي') 1
$sizeInput = New-Choice 'حجم الخط' 166 @('صغير', 'متوسط', 'كبير', 'كبير جدًا') 1
$toneInput = New-Choice 'لون النص' 202 @('أبيض', 'ذهبي') 0
$startButton = New-Control Button 'حدد منطقة الحوار' 20 245 245 37
$stopButton = New-Control Button 'إيقاف' 280 245 115 37
$autoButton = New-Control Button 'اقرأ صورة اللعبة كاملة' 20 290 375 32
$focusButton = New-Control Button 'حدد رسائل الجوال أو الإعدادات' 20 330 375 32
$startButton.Enabled = $false
$autoButton.Enabled = $false
$focusButton.Enabled = $false
$stopButton.Enabled = $false
$testButton = New-Control Button 'اختبار الترجمة على التلفزيون' 20 370 375 32
$testButton.Enabled = $false
$previewButton = New-Control Button 'معاينة آخر لقطة من اللعبة' 20 410 375 32
$previewButton.Enabled = $false
$statusLabel = New-Control Label 'افتح ريموت الجوال في سكن على التلفزيون وخذ رمز اللابتوب.' 20 452 380 44
$detailLabel = New-Control Label '' 20 501 380 44
$script:token = ''
$script:tvAddress = ''
$script:job = ''
$script:framesWithoutText = 0
$script:testCaption = $false
$script:seen = $false
$script:windowKey = ''
$script:nextCaptureAt = 0L
$script:retryAt = 0L
$script:rejectedRequests = 0
$script:resumeSelection = $false
$script:readingActive = $false
$script:pickMode = ''
$script:captureMode = ''
$script:pickWindow = [IntPtr]::Zero
$script:legacyCapture = $false
$script:selectedWindow = [IntPtr]::Zero
$script:selectedOwner = 0
$script:selectedClient = [System.Drawing.Rectangle]::Empty
$script:selectedArea = [System.Drawing.Rectangle]::Empty
$script:lastFrame = $null
$script:lastResult = ''
$readingClock = [Diagnostics.Stopwatch]::StartNew()
$windowSettleMs = 350
$frameIntervalMs = 650
$configPath = Join-Path $env:LOCALAPPDATA 'Sakan\positioned-captions.xml'
$timer = New-Object System.Windows.Forms.Timer -Property @{ Interval = 150 }

function Save-Connection {
    if (-not $script:token -or $addressInput.Text.Trim() -ne $script:tvAddress) { return }
    $null = New-Item -ItemType Directory -Force (Split-Path $configPath)
    $settings = [pscustomobject]@{
        Address = $script:tvAddress
        Token = ConvertTo-SecureString $script:token -AsPlainText -Force
        Language = $languageInput.SelectedIndex
        Font = $fontInput.SelectedIndex
        Size = $sizeInput.SelectedIndex
        Tone = $toneInput.SelectedIndex
        Mode = if ($script:readingActive -and -not $script:testCaption -and -not $script:pickMode) {
            $script:captureMode
        } else { '' }
        Reference = @($script:selectedClient.X, $script:selectedClient.Y, $script:selectedClient.Width, $script:selectedClient.Height)
        Selection = @($script:selectedArea.X, $script:selectedArea.Y, $script:selectedArea.Width, $script:selectedArea.Height)
    }
    $settings | Export-Clixml -LiteralPath "$configPath.tmp"
    if ([IO.File]::Exists($configPath)) {
        [IO.File]::Replace("$configPath.tmp", $configPath, [NullString]::Value)
    }
    else { [IO.File]::Move("$configPath.tmp", $configPath) }
}

function Select-GameArea([Drawing.Rectangle]$bounds, [Drawing.Rectangle]$screen) {
    $snapshot = [SakanGameCapture]::Snapshot($bounds, $screen)
    try {
        if ([SakanGameCapture]::IsNearlyBlack($snapshot)) {
            return @{ waitingForImage = $true }
        }
        $selection = @{ start = $null; area = $null; screenArea = $null; source = $bounds }
        $overlay = New-Object System.Windows.Forms.Form -Property @{
            Text = 'حدد النص على لقطة اللعبة'; Size = '900,550'; TopMost = $true
            StartPosition = 'CenterScreen'; BackColor = 'White'; BackgroundImage = $snapshot
            BackgroundImageLayout = 'Stretch'; Cursor = 'Cross'
            KeyPreview = $true; ShowInTaskbar = $false; Tag = $selection
        }
        $instruction = New-Object System.Windows.Forms.Label -Property @{
            Text = 'اسحب حول النص على هذه اللقطة الثابتة. Esc للإلغاء.'
            AutoSize = $true; Top = 8; Left = 8; BackColor = 'Black'; ForeColor = 'White'; Font = $uiFont
        }
        $overlay.Controls.Add($instruction)
        $overlay.add_KeyDown({ param($sender, $e) if ($e.KeyCode -eq 'Escape') { $sender.Close() } })
        $overlay.add_MouseDown({
            param($sender, $e)
            if ($e.Button -ne 'Left') { return }
            $sender.Tag.start = $e.Location
            $sender.Capture = $true
        })
        $overlay.add_MouseMove({
            param($sender, $e)
            $selection = $sender.Tag
            if ($null -eq $selection.start) { return }
            $selection.area = [Drawing.Rectangle]::FromLTRB(
                [Math]::Min($e.X, $selection.start.X), [Math]::Min($e.Y, $selection.start.Y),
                [Math]::Max($e.X, $selection.start.X), [Math]::Max($e.Y, $selection.start.Y))
            $sender.Invalidate()
        })
        $overlay.add_Paint({
            param($sender, $e)
            if ($null -ne $sender.Tag.area) { $e.Graphics.DrawRectangle([Drawing.Pens]::Yellow, $sender.Tag.area) }
        })
        $overlay.add_MouseUp({
            param($sender, $e)
            $selection = $sender.Tag
            if ($e.Button -ne 'Left' -or $null -eq $selection.start) { return }
            $rectangle = [Drawing.Rectangle]::FromLTRB(
                    [Math]::Min($e.X, $selection.start.X), [Math]::Min($e.Y, $selection.start.Y),
                    [Math]::Max($e.X, $selection.start.X), [Math]::Max($e.Y, $selection.start.Y))
            $mapped = [SakanGameCapture]::MapSelection($selection.source, $sender.ClientSize, $rectangle)
            $sender.Capture = $false
            $selection.start = $null
            if ($mapped.Width -ge 24 -and $mapped.Height -ge 12) {
                $selection.screenArea = $mapped
                $sender.Close()
            }
        })
        try {
            [void]$overlay.ShowDialog()
            return @{ area = $selection.screenArea }
        } finally { $overlay.Dispose() }
    } finally { $snapshot.Dispose() }
}

function Start-Reading {
    if (-not $script:token) { return }
    $script:job = ''
    $script:windowKey = ''
    $script:retryAt = 0L
    $script:readingActive = $true
    $script:lastFrame = $null
    $script:lastResult = ''
    $previewButton.Enabled = $false
    $startButton.Enabled = $false
    $autoButton.Enabled = $false
    $focusButton.Enabled = $false
    $stopButton.Enabled = $true
    $testButton.Enabled = $true
    $pairButton.Enabled = $false
    $addressInput.ReadOnly = $true
    $languageInput.Enabled = $false
    $statusLabel.Text = 'خلّ نافذة اللعبة ظاهرة على اللابتوب.'
    $detailLabel.Text = 'بانتظار أول لقطة من اللعبة.'
    $timer.Start()
}

$pairButton.add_Click({
    try {
        $script:tvAddress = Get-PrivateAddress $addressInput.Text.Trim()
        if ($codeInput.Text -notmatch '^[0-9]{6}$') { throw 'أدخل رمز اللابتوب من ستة أرقام.' }
        $cap = Invoke-RestMethod -Uri "http://$($script:tvAddress):8787/game-frame" -TimeoutSec 3 -MaximumRedirection 0
        if (-not $cap.positionedCaptions) { throw 'حدّث سكن على التلفزيون إلى 4.27.' }
        $reply = Invoke-Sakan '/pair' @{code = $codeInput.Text; device = 'laptop'}
        if (-not $reply.token -or $reply.device -ne 'laptop') { throw 'تعذّر ربط اللابتوب. استخدم الرمز المخصص له.' }
        $script:token = $reply.token
        $codeInput.Clear()
        Stop-Reading
        $statusLabel.Text = 'تم الربط. اضغط «حدد منطقة الحوار».'
        try { Save-Connection } catch { $statusLabel.Text = 'تم الربط. تعذّر حفظ الاقتران على ويندوز.' }
    } catch {
        $script:token = ''
        $startButton.Enabled = $false
        $autoButton.Enabled = $false
        $focusButton.Enabled = $false
        $testButton.Enabled = $false
        $statusLabel.Text = $_.Exception.Message
    }
})

function Send-WindowsCaption([string]$action, [string]$text = '') {
    Invoke-Sakan '/command' @{
        command = 'gameCaptions'; action = $action; language = $script:ocrLanguage
        text = $text
    }
}

function Clear-GameTranslation {
    try {
        if ($script:legacyCapture) { Send-WindowsCaption 'clear' | Out-Null }
        else { Invoke-Sakan '/game-frame/clear' @{} | Out-Null }
    } catch {}
    $script:seen = $false
    $script:job = ''
    $script:framesWithoutText = 0
}

function Submit-SelectedStyle([byte[]]$image, [string]$coordinates) {
    Submit-GameFrame $image @('en','es')[$languageInput.SelectedIndex] `
        @('regular','bold','compact','serif')[$fontInput.SelectedIndex] `
        @('18','24','30','38')[$sizeInput.SelectedIndex] @('white','gold')[$toneInput.SelectedIndex] ($script:captureMode -ne 'whole') $coordinates
}

function Get-RemotePlayOwner([IntPtr]$window) {
    if ($window -eq [IntPtr]::Zero) { return }
    $owner = [SakanGameCapture]::WindowOwner($window)
    if ($owner -eq 0 -or $owner -eq $PID) { return }
    $isGame = [SakanGameCapture]::IsRemotePlayTitle($window)
    if (-not $isGame) {
        $process = Get-Process -Id $owner -ErrorAction SilentlyContinue
        if ($null -eq $process) { return }
        try { $isGame = $process.ProcessName -in @('RemotePlay', 'Remote Play') }
        finally { $process.Dispose() }
    }
    if ($isGame) { return $owner }
}
function Set-CaptureWindow([IntPtr]$window) {
    $owner = Get-RemotePlayOwner $window
    if (-not $owner) { return }
    if ($script:pickWindow -ne $window) {
        $script:pickWindow = $window
        $script:nextCaptureAt = $readingClock.ElapsedMilliseconds + $windowSettleMs
        return
    }
    if ($readingClock.ElapsedMilliseconds -lt $script:nextCaptureAt) { return }
    $client = [SakanGameCapture]::ClientArea($window)
    $screen = [System.Windows.Forms.SystemInformation]::VirtualScreen
    if ($client.IsEmpty -or -not $screen.IntersectsWith($client)) {
        $statusLabel.Text = 'بانتظار ظهور نافذة Remote Play على اللابتوب.'
        return
    }
    if (-not $script:resumeSelection) {
        $crop = $client
        if ($script:pickMode -ne 'whole') {
            $area = Select-GameArea $client $screen
            if ($area.waitingForImage) {
                $script:nextCaptureAt = $readingClock.ElapsedMilliseconds + 600
                $statusLabel.Text = 'بانتظار صورة واضحة من Remote Play لتحديد النص.'
                return
            }
            if ($null -eq $area.area) {
                Stop-Reading
                $statusLabel.Text = 'أُلغي التحديد.'
                return
            }
            $crop = $area.area
        }
        $script:selectedClient = $client
        $script:selectedArea = $crop
    }
    $script:resumeSelection = $false
    $script:captureMode = $script:pickMode
    $script:selectedWindow = $window
    $script:selectedOwner = $owner
    $script:pickMode = ''
    $statusLabel.Text = 'خلّ Remote Play في الواجهة عشان تبدأ القراءة.'
    try { Save-Connection } catch {}
}

$timer.add_Tick({
    if (-not $script:readingActive -or $readingClock.ElapsedMilliseconds -lt $script:retryAt) { return }
    $timer.Stop()
    try {
        if ($script:testCaption) {
            $result = Send-WindowsCaption 'status'
            $detailLabel.Text = $result.message
            if (-not $result.busy) {
                $script:testCaption = $false
                $script:seen = $true
                $script:readingActive = $false
                $testButton.Enabled = $true
                $startButton.Enabled = $true
                $autoButton.Enabled = $true
                $focusButton.Enabled = $true
                $pairButton.Enabled = $true
                $statusLabel.Text = 'انتهى الاختبار. اضغط بدء القراءة للرجوع للعبة.'
            }
            return
        }
        $window = [SakanGameCapture]::GetForegroundWindow()
        if ($script:pickMode) {
            Set-CaptureWindow $window
            return
        }
        $owner = [SakanGameCapture]::WindowOwner($window)
        if ($window -ne $script:selectedWindow -or $owner -ne $script:selectedOwner) {
            if (-not (Get-RemotePlayOwner $window)) {
                if ($script:seen) { Clear-GameTranslation }
                $script:windowKey = ''
                $statusLabel.Text = 'القراءة معلّقة. ترجع تلقائيًا عند فتح نافذة Remote Play.'
                return
            }
            $script:selectedWindow = $window
            $script:selectedOwner = $owner
        }
        $client = [SakanGameCapture]::ClientArea($window)
        $screen = [System.Windows.Forms.SystemInformation]::VirtualScreen
        if ($client.IsEmpty -or -not $screen.IntersectsWith($client)) {
            if ($script:seen) { Clear-GameTranslation }
            $script:windowKey = ''
            $statusLabel.Text = 'تُستأنف القراءة تلقائيًا عندما تظهر نافذة Remote Play كاملة.'
            return
        }
        $key = "$window/$client"
        if ($key -ne $script:windowKey) {
            if ($script:seen) { Clear-GameTranslation }
            $script:windowKey = $key
            $script:nextCaptureAt = $readingClock.ElapsedMilliseconds + $windowSettleMs
            return
        }
        if ($script:job) {
            $result = Invoke-Sakan '/game-frame/status' @{id = $script:job} -allowRejected
            if ($result.ok -eq $false) {
                $script:job = ''
                $detailLabel.Text = $result.message
            } elseif ($result.done) {
                $script:job = ''
                $detailLabel.Text = $result.message
                $script:lastResult = if ($result.rows) {
                    ($result.rows | ForEach-Object { $_.source + '  ←  ' + $_.arabic }) -join [Environment]::NewLine
                } else { $result.message }
                if ($result.rows) { $script:framesWithoutText = 0 }
                else {
                    $script:framesWithoutText++
                    if ($script:framesWithoutText -ge 2) { Clear-GameTranslation }
                }
            } else {
                $statusLabel.Text = $result.message
                return
            }
        }
        if ($readingClock.ElapsedMilliseconds -lt $script:nextCaptureAt) { return }
        if ([SakanGameCapture]::GetForegroundWindow() -ne $window -or
                -not $client.Equals([SakanGameCapture]::ClientArea($window))) { return }
        $script:nextCaptureAt = $readingClock.ElapsedMilliseconds + $frameIntervalMs
        $crop = [SakanGameCapture]::RemapSelection($script:selectedClient, $script:selectedArea, $client)
        $frame = [SakanGameCapture]::CaptureFrame($client, $crop, ($script:captureMode -eq 'selection'), $screen)
        $script:lastFrame = $frame.Preview
        $previewButton.Enabled = $true
        if ($null -eq $frame.Upload) {
            $detailLabel.Text = 'صورة اللعبة طلعت سوداء. ننتظر لقطة ظاهرة من Remote Play.'
            $script:lastResult = $detailLabel.Text
            $statusLabel.Text = 'تعذّر التقاط صورة واضحة.'
            return
        }
        $script:seen = $true
        $statusLabel.Text = 'تم التقاط لقطة من اللعبة. جارٍ إرسالها للتلفزيون.'
        $result = Submit-SelectedStyle $frame.Upload $frame.Coordinates
        $script:job = $result.id
        $statusLabel.Text = 'صورة Remote Play وصلت إلى سكن.'
    } catch [System.Management.Automation.PipelineStoppedException] {
        $script:readingActive = $false
        $form.Close()
    } catch {
        $script:retryAt = $readingClock.ElapsedMilliseconds + 3000
        if ($script:readingActive -and -not $script:testCaption) {
            $statusLabel.Text = 'تعثّرت القراءة مؤقتًا. سكن يعيد المحاولة تلقائيًا.'
        }
        $detailLabel.Text = $_.Exception.Message
        if ($script:testCaption) {
            $script:testCaption = $false
            $script:readingActive = $false
            $testButton.Enabled = $true
            $startButton.Enabled = $true
            $autoButton.Enabled = $true
            $focusButton.Enabled = $true
            $pairButton.Enabled = $true
            $statusLabel.Text = 'تعذّر إكمال الاختبار.'
        }
        if ($_.Exception.Response -and [int]$_.Exception.Response.StatusCode -eq 401) {
            $script:rejectedRequests++
            if ($script:rejectedRequests -lt 2) {
                $statusLabel.Text = 'سكن يتحقق من الاقتران وبيحاول مرة ثانية.'
                return
            }
            Stop-Reading
            $script:token = ''
            Remove-Item -LiteralPath $configPath -ErrorAction SilentlyContinue
            $startButton.Enabled = $false
            $autoButton.Enabled = $false
            $focusButton.Enabled = $false
            $testButton.Enabled = $false
            $form.WindowState = 'Normal'
            $statusLabel.Text = 'انتهى الاقتران. أدخل رمز اللابتوب من التلفزيون.'
        }
    } finally {
        if ($script:readingActive -and -not $form.IsDisposed) { $timer.Start() }
    }
})

function Stop-Reading {
    $script:readingActive = $false
    $script:pickMode = ''
    $script:resumeSelection = $false
    $timer.Stop()
    if ($script:seen -or $script:testCaption) { Clear-GameTranslation }
    $script:legacyCapture = $false
    $script:testCaption = $false
    $addressInput.ReadOnly = $false
    $languageInput.Enabled = $true
    $startButton.Enabled = [bool]$script:token
    $autoButton.Enabled = [bool]$script:token
    $focusButton.Enabled = [bool]$script:token
    $testButton.Enabled = [bool]$script:token
    $stopButton.Enabled = $false
    $pairButton.Enabled = $true
    $statusLabel.Text = 'توقفت القراءة.'
    $detailLabel.Text = ''
}
function Start-SelectedCapture([string]$mode) {
    if ($addressInput.Text.Trim() -ne $script:tvAddress) {
        $statusLabel.Text = 'اربط سكن من جديد إذا تغيّر عنوان التلفزيون.'
        return
    }
    Stop-Reading
    $script:pickWindow = [IntPtr]::Zero
    $script:pickMode = $mode
    Start-Reading
    $statusLabel.Text = 'اضغط داخل نافذة اللعبة في Remote Play لتبدأ.'
}

$startButton.add_Click({ Start-SelectedCapture 'region' })
$autoButton.add_Click({ Start-SelectedCapture 'whole' })
$focusButton.add_Click({ Start-SelectedCapture 'selection' })
$testButton.add_Click({
    Stop-Reading
    try {
        $script:retryAt = 0L
        $script:ocrLanguage = @('en','es')[$languageInput.SelectedIndex]
        $sample = if ($script:ocrLanguage -eq 'es') { 'Gira a la izquierda en el puente.' }
            else { 'Turn left at the bridge.' }
        $result = Send-WindowsCaption 'translate' $sample
        $script:legacyCapture = $true
        $script:testCaption = $true
        $statusLabel.Text = 'جارٍ اختبار الترجمة. راقب التلفزيون.'
        $detailLabel.Text = $result.message
        $testButton.Enabled = $false
        $startButton.Enabled = $false
        $autoButton.Enabled = $false
        $focusButton.Enabled = $false
        $stopButton.Enabled = $true
        $pairButton.Enabled = $false
        $script:readingActive = $true
        $timer.Start()
    } catch {
        $detailLabel.Text = $_.Exception.Message
    }
})
$stopButton.add_Click({
    Stop-Reading
    try { Save-Connection } catch { $detailLabel.Text = $_.Exception.Message }
})
$previewButton.add_Click({
    if ($null -eq $script:lastFrame) { return }
    $bytes = [IO.MemoryStream]::new([byte[]]$script:lastFrame)
    $image = $null
    $preview = $null
    try {
        $image = [Drawing.Image]::FromStream($bytes)
        $preview = New-Object Windows.Forms.Form -Property @{
            Text = 'آخر لقطة ونتيجة القراءة'; StartPosition = 'CenterParent'; Size = '900,675'
        }
        $picture = New-Object Windows.Forms.PictureBox -Property @{ Dock = 'Fill'; SizeMode = 'Zoom'; Image = $image }
        $resultText = New-Object Windows.Forms.TextBox -Property @{
            Dock = 'Bottom'; Height = 120; Multiline = $true; ReadOnly = $true; ScrollBars = 'Vertical'
            RightToLeft = 'Yes'; Text = $script:lastResult
        }
        $preview.Controls.Add($picture)
        $preview.Controls.Add($resultText)
        [void]$preview.ShowDialog($form)
    } finally {
        if ($null -ne $preview) { $preview.Dispose() }
        if ($null -ne $image) { $image.Dispose() }
        $bytes.Dispose()
    }
})
$form.add_FormClosing({
    $script:readingActive = $false
    $timer.Stop()
})
foreach ($setting in @($languageInput,$fontInput,$sizeInput,$toneInput)) {
    $setting.add_SelectedIndexChanged({ try { Save-Connection } catch { $statusLabel.Text = $_.Exception.Message } })
}
$form.add_Shown({
    if (-not (Test-Path -LiteralPath $configPath)) { return }
    try {
        $saved = Import-Clixml -LiteralPath $configPath
        $script:tvAddress = Get-PrivateAddress $saved.Address
        $addressInput.Text = $script:tvAddress
        $languageInput.SelectedIndex = $saved.Language
        $fontInput.SelectedIndex = $saved.Font
        $sizeInput.SelectedIndex = $saved.Size
        $toneInput.SelectedIndex = $saved.Tone
        $script:token = [Net.NetworkCredential]::new('', $saved.Token).Password
        Stop-Reading
        $statusLabel.Text = 'التلفزيون مربوط. اضغط «حدد منطقة الحوار».'
        if ($saved.Mode -in @('whole', 'region', 'selection') -and $saved.Reference.Count -eq 4 -and $saved.Selection.Count -eq 4) {
            $box = [int[]]$saved.Reference
            $area = [int[]]$saved.Selection
            $client = [Drawing.Rectangle]::new($box[0], $box[1], $box[2], $box[3])
            $selection = [Drawing.Rectangle]::new($area[0], $area[1], $area[2], $area[3])
            if ($client.Width -ge 160 -and $client.Height -ge 90 -and $selection.Width -ge 24 -and
                    $selection.Height -ge 12 -and $client.Contains($selection)) {
                $script:selectedClient = $client
                $script:selectedArea = $selection
                $script:resumeSelection = $true
                $script:pickMode = $saved.Mode
                Start-Reading
                $statusLabel.Text = 'تم حفظ منطقة القراءة. سكن يستأنف تلقائيًا عند ظهور Remote Play.'
            }
        }
    } catch { $statusLabel.Text = 'أدخل رمز اللابتوب لربط سكن من جديد.' }
})
try { [void]$form.ShowDialog() }
catch [System.Management.Automation.PipelineStoppedException] {}
finally {
    $timer.Dispose()
    $form.Dispose()
    $uiFont.Dispose()
    if ($script:seen -or $script:testCaption) { Clear-GameTranslation }
}
