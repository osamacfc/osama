@echo off
powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -STA -File "%~dp0Sakan-Game-Captions.ps1"
if errorlevel 1 pause
