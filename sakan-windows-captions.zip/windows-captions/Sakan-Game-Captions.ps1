﻿#requires -Version 5.1
Add-Type -AssemblyName System.Windows.Forms, System.Drawing, System.Runtime.WindowsRuntime
Add-Type @'
using System.Runtime.InteropServices;
public static class SakanDisplay {
    [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
}
'@
[void][SakanDisplay]::SetProcessDPIAware()
[Windows.Storage.Streams.InMemoryRandomAccessStream, Windows.Storage.Streams, ContentType=WindowsRuntime] | Out-Null
[Windows.Storage.Streams.DataWriter, Windows.Storage.Streams, ContentType=WindowsRuntime] | Out-Null
[Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType=WindowsRuntime] | Out-Null
[Windows.Graphics.Imaging.SoftwareBitmap, Windows.Graphics.Imaging, ContentType=WindowsRuntime] | Out-Null
[Windows.Graphics.Imaging.BitmapPixelFormat, Windows.Graphics.Imaging, ContentType=WindowsRuntime] | Out-Null
[Windows.Graphics.Imaging.BitmapAlphaMode, Windows.Graphics.Imaging, ContentType=WindowsRuntime] | Out-Null
[Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType=WindowsRuntime] | Out-Null
[Windows.Media.Ocr.OcrResult, Windows.Foundation, ContentType=WindowsRuntime] | Out-Null
[Windows.Globalization.Language, Windows.Globalization, ContentType=WindowsRuntime] | Out-Null

$awaitMethod = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.IsGenericMethodDefinition -and
    $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
} | Select-Object -First 1

function Wait-Operation($operation, [Type]$resultType) {
    $task = $awaitMethod.MakeGenericMethod($resultType).Invoke($null, @($operation))
    return $task.GetAwaiter().GetResult()
}

function Get-PrivateAddress([string]$address) {
    if ($address -notmatch '^\d{1,3}(?:\.\d{1,3}){3}$') { throw 'أدخل عنوان التلفزيون المحلي.' }
    [ipaddress]$ip = [ipaddress]::None
    if (-not [ipaddress]::TryParse($address, [ref]$ip) -or $address -ne $ip.ToString()) {
        throw 'أدخل عنوان التلفزيون المحلي.'
    }
    $number = $ip.GetAddressBytes()
    if ($number[0] -ne 10 -and
        -not ($number[0] -eq 172 -and $number[1] -ge 16 -and $number[1] -le 31) -and
        -not ($number[0] -eq 192 -and $number[1] -eq 168)) { throw 'استخدم عنوانًا من شبكة البيت.' }
    return $ip.ToString()
}

function Invoke-Sakan([string]$path, [hashtable]$body) {
    $headers = @{}
    if ($path -ne '/pair') { $headers.Authorization = "Bearer $($script:token)" }
    $json = ConvertTo-Json -InputObject $body -Compress
    $reply = Invoke-RestMethod -Method Post -Uri "http://$($script:tvAddress):8787$path" -Headers $headers `
        -ContentType 'application/json' -Body ([Text.Encoding]::UTF8.GetBytes($json)) -TimeoutSec 3 -MaximumRedirection 0
    if ($reply.ok -eq $false) { throw $reply.message }
    return $reply
}

function Send-Caption([string]$action, [string]$text = '') {
    Invoke-Sakan '/command' @{
        command = 'gameCaptions'
        action = $action
        language = $script:language
        text = $text
    } | Out-Null
}

function Select-SubtitleArea {
    $selection = @{start = $null; area = $null}
    $bounds = [System.Windows.Forms.SystemInformation]::VirtualScreen
    $overlay = New-Object System.Windows.Forms.Form -Property @{
        FormBorderStyle = 'None'; Bounds = $bounds; TopMost = $true
        StartPosition = 'Manual'; BackColor = 'Black'; Opacity = 0.35
        Cursor = 'Cross'; KeyPreview = $true; ShowInTaskbar = $false; Tag = $selection
    }
    $overlay.add_KeyDown({ param($sender, $e) if ($e.KeyCode -eq 'Escape') { $sender.Close() } })
    $overlay.add_MouseDown({
        param($sender, $e)
        if ($e.Button -eq 'Left') {
            $selection = $sender.Tag
            $selection.start = $e.Location
            $selection.area = $null
            $sender.Capture = $true
        }
    })
    $overlay.add_MouseMove({
        param($sender, $e)
        $selection = $sender.Tag
        if ($null -eq $selection.start) { return }
        $x = [Math]::Min($e.X, $selection.start.X)
        $y = [Math]::Min($e.Y, $selection.start.Y)
        $width = [Math]::Abs($e.X - $selection.start.X)
        $height = [Math]::Abs($e.Y - $selection.start.Y)
        $selection.area = New-Object System.Drawing.Rectangle($x, $y, $width, $height)
        $sender.Invalidate()
    })
    $overlay.add_Paint({
        param($sender, $e)
        if ($null -ne $sender.Tag.area) { $e.Graphics.DrawRectangle([System.Drawing.Pens]::Yellow, $sender.Tag.area) }
    })
    $overlay.add_MouseUp({
        param($sender, $e)
        if ($e.Button -eq 'Left') {
            $sender.Capture = $false
            $sender.Close()
        }
    })
    try {
        [void]$overlay.ShowDialog()
        if ($null -ne $selection.area -and $selection.area.Width -ge 100 -and $selection.area.Height -ge 18) {
            $area = $selection.area
            return New-Object System.Drawing.Rectangle(($bounds.X + $area.X), ($bounds.Y + $area.Y), $area.Width, $area.Height)
        }
    } finally { $overlay.Dispose() }
}

function Read-Subtitle([System.Drawing.Rectangle]$area) {
    $snapshot = New-Object System.Drawing.Bitmap($area.Width, $area.Height)
    $buffer = New-Object System.IO.MemoryStream
    $stream = [Windows.Storage.Streams.InMemoryRandomAccessStream]::new()
    $writer = [Windows.Storage.Streams.DataWriter]::new($stream)
    $bitmap = $null
    try {
        $surface = [System.Drawing.Graphics]::FromImage($snapshot)
        try { $surface.CopyFromScreen($area.Location, [System.Drawing.Point]::Empty, $area.Size) }
        finally { $surface.Dispose() }

        # Detect a missing/black video surface separately from a frame with no subtitle.
        $bright = 0
        for ($y = 1; $y -lt 7; $y++) {
            for ($x = 1; $x -lt 11; $x++) {
                $sampleX = [int][Math]::Floor($area.Width * $x / 11)
                $sampleY = [int][Math]::Floor($area.Height * $y / 7)
                if ($snapshot.GetPixel($sampleX, $sampleY).GetBrightness() -gt 0.09) { $bright++ }
            }
        }
        $snapshot.Save($buffer, [System.Drawing.Imaging.ImageFormat]::Png)
        $writer.WriteBytes($buffer.ToArray())
        [void](Wait-Operation ($writer.StoreAsync()) ([uint32]))
        [void]$writer.DetachStream()
        $stream.Seek(0)
        $decoder = Wait-Operation ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
        $decoded = Wait-Operation ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
        try {
            $bitmap = [Windows.Graphics.Imaging.SoftwareBitmap]::Convert($decoded,
                [Windows.Graphics.Imaging.BitmapPixelFormat]::Bgra8,
                [Windows.Graphics.Imaging.BitmapAlphaMode]::Premultiplied)
        } finally { $decoded.Dispose() }
        $result = Wait-Operation ($script:engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
        $text = ($result.Lines.Text -join ' ').Trim() -replace '\s+', ' '
        if ($text.Length -gt 360 -or $text -notmatch '[A-Za-zÀ-ÖØ-öø-ÿ].*[A-Za-zÀ-ÖØ-öø-ÿ]') { $text = '' }
        return @{Text = $text; Picture = ($bright -gt 0 -or [bool]$text)}
    } finally {
        if ($null -ne $bitmap) { $bitmap.Dispose() }
        $writer.Dispose()
        $stream.Dispose()
        $buffer.Dispose()
        $snapshot.Dispose()
    }
}

$form = New-Object System.Windows.Forms.Form -Property @{
    Text = 'ترجمة اللعب · سكن'; StartPosition = 'CenterScreen'; Size = '450,325'
    FormBorderStyle = 'FixedDialog'; MaximizeBox = $false
}
$font = New-Object System.Drawing.Font('Segoe UI', 10)
$form.Font = $font
function New-Control($type, $text, $left, $top, $width, $height) {
    $control = New-Object "System.Windows.Forms.$type" -Property @{
        Text = $text; Left = $left; Top = $top; Width = $width; Height = $height
    }
    $form.Controls.Add($control)
    return $control
}

[void](New-Control Label 'عنوان التلفزيون' 20 20 135 25)
$addressInput = New-Control TextBox '192.168.8.28' 165 20 230 26
[void](New-Control Label 'رمز الاقتران' 20 57 135 25)
$codeInput = New-Control TextBox '' 165 57 115 26
$codeInput.MaxLength = 6
$pairButton = New-Control Button 'ربط التلفزيون' 290 54 105 32
[void](New-Control Label 'لغة الحوار' 20 94 135 25)
$languageInput = New-Control ComboBox '' 165 94 230 26
$languageInput.DropDownStyle = 'DropDownList'
[void]$languageInput.Items.AddRange(@('الإنجليزية', 'الإسبانية'))
$languageInput.SelectedIndex = 0
$startButton = New-Control Button 'حدد مكان الترجمة وابدأ' 20 140 245 37
$stopButton = New-Control Button 'إيقاف' 280 140 115 37
$startButton.Enabled = $false
$stopButton.Enabled = $false
$statusLabel = New-Control Label 'افتح ريموت الجوال في سكن، واختر ربط لابتوب للترجمة وخذ رمزه.' 20 195 378 75
$script:token = ''
$script:tvAddress = ''
$script:language = 'en'
$script:engine = $null
$script:screenArea = $null
$script:previous = $null
$script:displayed = ''
$timer = New-Object System.Windows.Forms.Timer -Property @{ Interval = 450 }

$pairButton.add_Click({
    try {
        $script:tvAddress = Get-PrivateAddress $addressInput.Text.Trim()
        if ($codeInput.Text -notmatch '^[0-9]{6}$') { throw 'أدخل رمز الاقتران من ستة أرقام.' }
        $reply = Invoke-Sakan '/pair' @{code = $codeInput.Text; device = 'laptop'}
        if (-not $reply.token) { throw 'تعذّر الاقتران بالتلفزيون.' }
        $script:token = $reply.token
        $codeInput.Clear()
        $startButton.Enabled = $true
        $statusLabel.Text = 'تم الربط. خلّ نافذة PS Remote Play ظاهرة وحدد مستطيل الترجمة.'
    } catch {
        $script:token = ''
        $startButton.Enabled = $false
        $statusLabel.Text = $_.Exception.Message
    }
})

$startButton.add_Click({
    try {
        $script:language = if ($languageInput.SelectedIndex -eq 1) { 'es' } else { 'en' }
        $ocrLanguage = [Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages | Where-Object {
            $_.LanguageTag -match "^$($script:language)(-|$)"
        } | Select-Object -First 1
        if ($null -eq $ocrLanguage) {
            throw "ثبّت اللغة $($languageInput.Text) مع دعم قراءة النص من إعدادات ويندوز."
        }
        $script:engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($ocrLanguage)
        if ($null -eq $script:engine) { throw 'تعذّر بدء قراءة النص بهذه اللغة.' }
        $form.Hide()
        try { $script:screenArea = Select-SubtitleArea }
        finally { $form.Show() }
        if ($null -eq $script:screenArea) { $statusLabel.Text = 'اسحب بالفأرة لتحديد منطقة سطر الترجمة.'; return }
        if ([Math]::Max($script:screenArea.Width, $script:screenArea.Height) -gt [Windows.Media.Ocr.OcrEngine]::MaxImageDimension) {
            throw 'المنطقة كبيرة. حدد منطقة سطر الترجمة.'
        }
        $script:previous = $null
        $script:displayed = ''
        $statusLabel.Text = 'القراءة شغّالة. خلّ نافذة Remote Play ظاهرة في نفس مكانها.'
        $form.WindowState = 'Minimized'
        $startButton.Enabled = $false
        $stopButton.Enabled = $true
        $pairButton.Enabled = $false
        $timer.Start()
    } catch { $statusLabel.Text = $_.Exception.Message }
})

$timer.add_Tick({
    try {
        $read = Read-Subtitle $script:screenArea
        $text = $read.Text
        if ($text -ceq $script:previous -and $text -cne $script:displayed) {
            if ($text) { Send-Caption 'translate' $text } else { Send-Caption 'clear' }
            $script:displayed = $text
        }
        $script:previous = $text
        if (-not $read.Picture) { $statusLabel.Text = 'منطقة الصورة المحددة سوداء.' }
        elseif (-not $text) { $statusLabel.Text = 'الصورة متاحة. بانتظار سطر واضح للقراءة.' }
        elseif ($text -ceq $script:displayed) { $statusLabel.Text = 'أُرسل السطر إلى سكن.' }
    } catch { $statusLabel.Text = $_.Exception.Message }
})

function Stop-Reading {
    $timer.Stop()
    if ($script:token) { try { Send-Caption 'clear' } catch {} }
    $startButton.Enabled = [bool]$script:token
    $stopButton.Enabled = $false
    $pairButton.Enabled = $true
    $statusLabel.Text = 'توقفت قراءة الشاشة.'
}
$stopButton.add_Click({ Stop-Reading })
$form.add_FormClosing({ Stop-Reading })
try { [void]$form.ShowDialog() }
finally { $timer.Dispose(); $font.Dispose(); $form.Dispose() }
