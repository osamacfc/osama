﻿#requires -Version 5.1
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
Add-Type -ReferencedAssemblies 'System.Drawing' -TypeDefinition @'
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text;
public static class SakanGameCapture {
    [StructLayout(LayoutKind.Sequential)]
    private struct Rect { public int Left, Top, Right, Bottom; }
    [StructLayout(LayoutKind.Sequential)]
    private struct Point { public int X, Y; }

    [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
    [DllImport("user32.dll")] static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
    public static void EnablePhysicalPixels() {
        try {
            if (SetThreadDpiAwarenessContext(new IntPtr(-4)) != IntPtr.Zero) return;
        } catch (EntryPointNotFoundException) {}
        SetProcessDPIAware();
    }
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr window, StringBuilder title, int capacity);
    public static bool IsRemotePlayTitle(IntPtr window) {
        var title = new StringBuilder(256);
        GetWindowText(window, title, title.Capacity);
        return string.Equals(title.ToString().Trim(), "PS Remote Play", StringComparison.OrdinalIgnoreCase);
    }
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr window, out int processId);
    public static int WindowOwner(IntPtr window) {
        int processId;
        GetWindowThreadProcessId(window, out processId);
        return processId;
    }
    [DllImport("user32.dll")] static extern bool IsIconic(IntPtr window);
    [DllImport("user32.dll")] static extern bool GetClientRect(IntPtr window, out Rect rect);
    [DllImport("user32.dll")] static extern bool ClientToScreen(IntPtr window, ref Point point);

    public static Rectangle ClientArea(IntPtr window) {
        if (window == IntPtr.Zero || IsIconic(window)) return Rectangle.Empty;
        Rect rect;
        if (!GetClientRect(window, out rect)) return Rectangle.Empty;
        var first = new Point { X = rect.Left, Y = rect.Top };
        var last = new Point { X = rect.Right, Y = rect.Bottom };
        if (!ClientToScreen(window, ref first) || !ClientToScreen(window, ref last))
            return Rectangle.Empty;
        // In a mirrored window, client x increases toward the left of the screen.
        Rectangle bounds = Rectangle.FromLTRB(Math.Min(first.X, last.X), Math.Min(first.Y, last.Y),
                Math.Max(first.X, last.X), Math.Max(first.Y, last.Y));
        return bounds.Width >= 160 && bounds.Height >= 90 ? bounds : Rectangle.Empty;
    }

    public static Bitmap Snapshot(Rectangle area, Rectangle screen) {
        Rectangle visible = Rectangle.Intersect(area, screen);
        if (visible.Width == 0 || visible.Height == 0)
            throw new ArgumentException("The game window is outside the display.");
        var image = new Bitmap(area.Width, area.Height, PixelFormat.Format24bppRgb);
        try {
            using (var graphics = Graphics.FromImage(image)) {
                graphics.Clear(Color.Black);
                graphics.CopyFromScreen(visible.X, visible.Y, visible.X - area.X, visible.Y - area.Y,
                    visible.Size, CopyPixelOperation.SourceCopy);
            }
            return image;
        } catch {
            image.Dispose();
            throw;
        }
    }

    public static Rectangle FitGameArea(Rectangle client) {
        int width = Math.Min(client.Width, client.Height * 16 / 9);
        int height = Math.Min(client.Height, client.Width * 9 / 16);
        return new Rectangle(client.X + (client.Width - width) / 2,
            client.Y + (client.Height - height) / 2, width, height);
    }

    public static byte[] CaptureDialogue(Rectangle client, Rectangle screen) {
        Rectangle game = FitGameArea(client);
        Rectangle band = Rectangle.FromLTRB(game.Left + game.Width / 10,
                game.Top + game.Height * 78 / 100, game.Right - game.Width / 10,
                game.Top + game.Height * 97 / 100);
        using (Bitmap image = Snapshot(band, screen)) return Encode(image, 1800);
    }

    static byte[] Encode(Bitmap image, int limit) {
        double scale = Math.Min(1.0, (double)limit / Math.Max(image.Width, image.Height));
        using (var scaled = new Bitmap(image, (int)(image.Width * scale), (int)(image.Height * scale)))
        using (var stream = new MemoryStream())
        using (var encoder = new EncoderParameters(1)) {
            var codec = Array.Find(ImageCodecInfo.GetImageEncoders(), item => item.FormatID == ImageFormat.Jpeg.Guid);
            foreach (long quality in new long[] { 82, 62, 42 }) {
                stream.SetLength(0);
                encoder.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, quality);
                try {
                    scaled.Save(stream, codec, encoder);
                } finally {
                    encoder.Param[0].Dispose();
                    encoder.Param[0] = null;
                }
                if (stream.Length <= 590000) return stream.ToArray();
            }
            throw new InvalidOperationException("The game image is too large.");
        }
    }
}
'@
[SakanGameCapture]::EnablePhysicalPixels()
[System.Windows.Forms.Application]::SetUnhandledExceptionMode(
    [System.Windows.Forms.UnhandledExceptionMode]::ThrowException)

function Get-PrivateAddress([string]$address) {
    if ($address -notmatch '^\d{1,3}(?:\.\d{1,3}){3}$') { throw 'أدخل عنوان التلفزيون المحلي.' }
    [ipaddress]$ip = [ipaddress]::None
    if (-not [ipaddress]::TryParse($address, [ref]$ip) -or $address -ne $ip.ToString()) {
        throw 'أدخل عنوان التلفزيون المحلي.'
    }
    $number = $ip.GetAddressBytes()
    if ($number[0] -ne 10 -and
        -not ($number[0] -eq 172 -and $number[1] -ge 16 -and $number[1] -le 31) -and
        -not ($number[0] -eq 192 -and $number[1] -eq 168)) { throw 'استخدم عنوانًا من شبكة البيت.' }
    return $ip.ToString()
}

function Invoke-Sakan([string]$path, [hashtable]$body, [switch]$allowRejected) {
    $headers = @{}
    if ($path -ne '/pair') { $headers.Authorization = "Bearer $($script:token)" }
    $json = ConvertTo-Json -Depth 5 -InputObject $body -Compress
    $reply = Invoke-RestMethod -Method Post -Uri "http://$($script:tvAddress):8787$path" -Headers $headers `
        -ContentType 'application/json' -Body ([Text.Encoding]::UTF8.GetBytes($json)) -TimeoutSec 3 -MaximumRedirection 0
    $script:rejectedRequests = 0
    if ($reply.ok -eq $false -and -not $allowRejected) { throw $reply.message }
    return $reply
}

function Stop-LocalReader {
    $script:pendingRead = $null
    if ($script:worker) {
        try { if (-not $script:worker.HasExited) { $script:worker.Kill() } }
        finally { $script:worker.Dispose(); $script:worker = $null }
    }
}
function Start-LocalReader {
    $python = Join-Path $env:LOCALAPPDATA 'SakanReader\venv\Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $python)) { throw 'افتح Setup-Local-Reader.cmd لتجهيز القراءة على اللابتوب.' }
    $cap = Invoke-RestMethod -Uri "http://$($script:tvAddress):8787/game-frame" -TimeoutSec 3 -MaximumRedirection 0
    if (-not $cap.localReader) { throw 'حدّث تطبيق سكن على التلفزيون للإصدار 4.33.' }
    $info = [Diagnostics.ProcessStartInfo]::new()
    $info.FileName = $python
    $info.Arguments = '-u "' + (Join-Path $PSScriptRoot 'live_reader.py') + '"'
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardInput = $true
    $info.RedirectStandardOutput = $true
    $script:worker = [Diagnostics.Process]::Start($info)
}


$form = New-Object System.Windows.Forms.Form -Property @{
    Text = 'ترجمة اللعب · سكن'; StartPosition = 'CenterScreen'; Size = '460,435'
    FormBorderStyle = 'FixedDialog'; MaximizeBox = $false
}
$uiFont = New-Object System.Drawing.Font('Segoe UI', 10)
$form.Font = $uiFont
function New-Control($type, $text, $left, $top, $width, $height) {
    $control = New-Object "System.Windows.Forms.$type" -Property @{
        Text = $text; Left = $left; Top = $top; Width = $width; Height = $height
    }
    $form.Controls.Add($control)
    return $control
}
function New-Choice($label, $top, $choices, $index) {
    [void](New-Control Label $label 20 $top 135 25)
    $box = New-Control ComboBox '' 165 $top 230 26
    $box.DropDownStyle = 'DropDownList'
    $box.Items.AddRange($choices)
    $box.SelectedIndex = $index
    return $box
}

[void](New-Control Label 'عنوان التلفزيون' 20 20 135 25)
$addressInput = New-Control TextBox '192.168.8.28' 165 20 230 26
[void](New-Control Label 'رمز اللابتوب' 20 57 135 25)
$codeInput = New-Control TextBox '' 165 57 115 26
$codeInput.MaxLength = 6
$pairButton = New-Control Button 'ربط التلفزيون' 290 54 105 32
$languageInput = New-Choice 'لغة النص' 94 @('الإنجليزية', 'الإسبانية') 0
$fontInput = New-Choice 'أسلوب الخط' 130 @('عادي', 'عريض', 'مضغوط', 'تقليدي') 1
$sizeInput = New-Choice 'حجم الخط' 166 @('صغير', 'متوسط', 'كبير', 'كبير جدًا') 1
$toneInput = New-Choice 'لون النص' 202 @('أبيض', 'ذهبي') 0
$stopButton = New-Control Button 'إيقاف' 280 245 115 37
$autoButton = New-Control Button 'حوار اللعبة · أسفل المنتصف' 20 245 245 37
$autoButton.Enabled = $false
$stopButton.Enabled = $false
$statusLabel = New-Control Label 'افتح ريموت الجوال في سكن على التلفزيون وخذ رمز اللابتوب.' 20 300 380 44
$detailLabel = New-Control Label '' 20 350 380 44
$script:token = ''
$script:tvAddress = ''
$script:seen = $false
$script:windowKey = ''
$script:nextCaptureAt = 0L
$script:retryAt = 0L
$script:rejectedRequests = 0
$script:readingActive = $false
$script:pickMode = ''
$script:pickWindow = [IntPtr]::Zero
$script:selectedWindow = [IntPtr]::Zero
$script:selectedOwner = 0
$readingClock = [Diagnostics.Stopwatch]::StartNew()
$windowSettleMs = 350
$frameIntervalMs = 350
$configPath = Join-Path $env:LOCALAPPDATA 'Sakan\positioned-captions.xml'
$timer = New-Object System.Windows.Forms.Timer -Property @{ Interval = 150 }

function Save-Connection {
    if (-not $script:token -or $addressInput.Text.Trim() -ne $script:tvAddress) { return }
    $null = New-Item -ItemType Directory -Force (Split-Path $configPath)
    $settings = [pscustomobject]@{
        Address = $script:tvAddress
        Token = ConvertTo-SecureString $script:token -AsPlainText -Force
        Language = $languageInput.SelectedIndex
        Font = $fontInput.SelectedIndex
        Size = $sizeInput.SelectedIndex
        Tone = $toneInput.SelectedIndex
        Mode = if ($script:readingActive) { 'dialogue' } else { '' }
    }
    $settings | Export-Clixml -LiteralPath "$configPath.tmp"
    if ([IO.File]::Exists($configPath)) {
        [IO.File]::Replace("$configPath.tmp", $configPath, [NullString]::Value)
    }
    else { [IO.File]::Move("$configPath.tmp", $configPath) }
}

function Start-Reading {
    if (-not $script:token) { return }
    $script:windowKey = ''
    $script:retryAt = 0L
    $script:readingActive = $true
    $autoButton.Enabled = $false
    $stopButton.Enabled = $true
    $pairButton.Enabled = $false
    $addressInput.ReadOnly = $true
    $languageInput.Enabled = $false
    $statusLabel.Text = 'خلّ نافذة اللعبة ظاهرة على اللابتوب.'
    $detailLabel.Text = 'بانتظار أول لقطة من اللعبة.'
    $timer.Start()
}

$pairButton.add_Click({
    try {
        $script:tvAddress = Get-PrivateAddress $addressInput.Text.Trim()
        if ($codeInput.Text -notmatch '^[0-9]{6}$') { throw 'أدخل رمز اللابتوب من ستة أرقام.' }
        $cap = Invoke-RestMethod -Uri "http://$($script:tvAddress):8787/game-frame" -TimeoutSec 3 -MaximumRedirection 0
        if (-not $cap.localReader) { throw 'حدّث سكن على التلفزيون إلى 4.33.' }
        $reply = Invoke-Sakan '/pair' @{code = $codeInput.Text; device = 'laptop'}
        if (-not $reply.token -or $reply.device -ne 'laptop') { throw 'تعذّر ربط اللابتوب. استخدم الرمز المخصص له.' }
        $script:token = $reply.token
        $codeInput.Clear()
        Stop-Reading
        $statusLabel.Text = 'تم الربط. اضغط «حوار اللعبة · أسفل المنتصف».'
        try { Save-Connection } catch { $statusLabel.Text = 'تم الربط. تعذّر حفظ الاقتران على ويندوز.' }
    } catch {
        $script:token = ''
        $autoButton.Enabled = $false
        $statusLabel.Text = $_.Exception.Message
    }
})

function Clear-GameTranslation {
    Stop-LocalReader
    try {
        Invoke-Sakan '/game-frame/clear' @{} | Out-Null
    } catch {}
    $script:seen = $false
}



function Get-RemotePlayOwner([IntPtr]$window) {
    if ($window -eq [IntPtr]::Zero) { return }
    $owner = [SakanGameCapture]::WindowOwner($window)
    if ($owner -eq 0 -or $owner -eq $PID) { return }
    $isGame = [SakanGameCapture]::IsRemotePlayTitle($window)
    if (-not $isGame) {
        $process = Get-Process -Id $owner -ErrorAction SilentlyContinue
        if ($null -eq $process) { return }
        try { $isGame = $process.ProcessName -in @('RemotePlay', 'Remote Play') }
        finally { $process.Dispose() }
    }
    if ($isGame) { return $owner }
}
function Set-CaptureWindow([IntPtr]$window) {
    $owner = Get-RemotePlayOwner $window
    if (-not $owner) {
        $statusLabel.Text = 'اضغط داخل صورة اللعبة في PS Remote Play على اللابتوب.'
        return
    }
    if ($script:pickWindow -ne $window) {
        $script:pickWindow = $window
        $script:nextCaptureAt = $readingClock.ElapsedMilliseconds + $windowSettleMs
        return
    }
    if ($readingClock.ElapsedMilliseconds -lt $script:nextCaptureAt) { return }
    $client = [SakanGameCapture]::ClientArea($window)
    $screen = [System.Windows.Forms.SystemInformation]::VirtualScreen
    if ($client.IsEmpty -or -not $screen.IntersectsWith($client)) {
        $statusLabel.Text = 'بانتظار ظهور نافذة Remote Play على اللابتوب.'
        return
    }
    $script:selectedWindow = $window
    $script:selectedOwner = $owner
    $script:pickMode = ''
    $statusLabel.Text = 'خلّ Remote Play في الواجهة عشان تبدأ القراءة.'
    try { Save-Connection } catch {}
}

$timer.add_Tick({
    if (-not $script:readingActive -or $readingClock.ElapsedMilliseconds -lt $script:retryAt) { return }
    $timer.Stop()
    try {
        $window = [SakanGameCapture]::GetForegroundWindow()
        if ($script:pickMode) {
            Set-CaptureWindow $window
            return
        }
        $owner = [SakanGameCapture]::WindowOwner($window)
        if ($window -ne $script:selectedWindow -or $owner -ne $script:selectedOwner) {
            if (-not (Get-RemotePlayOwner $window)) {
                if ($script:seen) { Clear-GameTranslation }
                $script:windowKey = ''
                $statusLabel.Text = 'القراءة معلّقة. ترجع تلقائيًا عند فتح نافذة Remote Play.'
                return
            }
            $script:selectedWindow = $window
            $script:selectedOwner = $owner
        }
        $client = [SakanGameCapture]::ClientArea($window)
        $screen = [System.Windows.Forms.SystemInformation]::VirtualScreen
        if ($client.IsEmpty -or -not $screen.IntersectsWith($client)) {
            if ($script:seen) { Clear-GameTranslation }
            $script:windowKey = ''
            $statusLabel.Text = 'تُستأنف القراءة تلقائيًا عندما تظهر نافذة Remote Play كاملة.'
            return
        }
        $key = "$window/$client"
        if ($key -ne $script:windowKey) {
            if ($script:seen) { Clear-GameTranslation }
            $script:windowKey = $key
            $script:nextCaptureAt = $readingClock.ElapsedMilliseconds + $windowSettleMs
            return
        }
        if ($script:pendingRead) {
            if ($script:pendingWrite.IsFaulted) { Stop-LocalReader; throw 'انقطع الاتصال بقارئ ويندوز وسيعاد تشغيله.' }
            if (-not $script:pendingRead.IsCompleted) {
                if ($readingClock.ElapsedMilliseconds - $script:frameAt -gt 90000) {
                    Stop-LocalReader
                    throw 'تأخرت القراءة المحلية وسيعيد سكن تشغيلها.'
                }
                return
            }
            $line = $script:pendingRead.GetAwaiter().GetResult()
            $script:pendingRead = $null
            if (-not $line) { Stop-LocalReader; throw 'توقف قارئ اللابتوب. تحقق من إعداد نماذج اللغة.' }
            $local = ConvertFrom-Json -InputObject $line
            if ($local.error) { throw ('تعذرت القراءة المحلية: ' + $local.error) }
            $elapsed = $readingClock.ElapsedMilliseconds - $script:frameAt
            if ($elapsed -lt 2500 -and $local.rows) {
                $display = Invoke-Sakan '/game-overlay' @{
                    rows = @($local.rows); coordinates = '0,1,0,0,0,1'
                    ttlMs = [Math]::Max(600, 2800 - $elapsed)
                    font = @('regular','bold','compact','serif')[$fontInput.SelectedIndex]
                    size = @('18','24','30','38')[$sizeInput.SelectedIndex]
                    tone = @('white','gold')[$toneInput.SelectedIndex]
                }
                $detailLabel.Text = $display.message
            } elseif (-not $local.rows) {
                $detailLabel.Text = 'بانتظار حوار أسفل الشاشة.'
            } else { $detailLabel.Text = 'جارٍ قراءة الحوار الحالي.' }
        }
        if ($readingClock.ElapsedMilliseconds -lt $script:nextCaptureAt) { return }
        if ([SakanGameCapture]::GetForegroundWindow() -ne $window -or
                -not $client.Equals([SakanGameCapture]::ClientArea($window))) { return }
        $script:nextCaptureAt = $readingClock.ElapsedMilliseconds + $frameIntervalMs
        $band = [SakanGameCapture]::CaptureDialogue($client, $screen)
        $script:seen = $true
        if (-not $script:worker -or $script:worker.HasExited) { Stop-LocalReader; Start-LocalReader }
        $payload = ConvertTo-Json -Compress -InputObject @{
            image = [Convert]::ToBase64String($band)
            language = @('en','es')[$languageInput.SelectedIndex]
        }
        $script:frameAt = $readingClock.ElapsedMilliseconds
        $script:pendingRead = $script:worker.StandardOutput.ReadLineAsync()
        $script:pendingWrite = $script:worker.StandardInput.WriteLineAsync($payload)
        $statusLabel.Text = 'القراءة والترجمة على اللابتوب.'
    } catch [System.Management.Automation.PipelineStoppedException] {
        $script:readingActive = $false
        $form.Close()
    } catch {
        $script:retryAt = $readingClock.ElapsedMilliseconds + 3000
        if ($script:readingActive) {
            $statusLabel.Text = 'تعثّرت القراءة مؤقتًا. سكن يعيد المحاولة تلقائيًا.'
        }
        $detailLabel.Text = $_.Exception.Message
        if ($_.Exception.Response -and [int]$_.Exception.Response.StatusCode -eq 401) {
            $script:rejectedRequests++
            if ($script:rejectedRequests -lt 2) {
                $statusLabel.Text = 'سكن يتحقق من الاقتران وبيحاول مرة ثانية.'
                return
            }
            Stop-Reading
            $script:token = ''
            Remove-Item -LiteralPath $configPath -ErrorAction SilentlyContinue
            $autoButton.Enabled = $false
            $form.WindowState = 'Normal'
            $statusLabel.Text = 'انتهى الاقتران. أدخل رمز اللابتوب من التلفزيون.'
        }
    } finally {
        if ($script:readingActive -and -not $form.IsDisposed) { $timer.Start() }
    }
})

function Stop-Reading {
    $script:readingActive = $false
    $script:pickMode = ''
    $timer.Stop()
    if ($script:seen) { Clear-GameTranslation }
    $addressInput.ReadOnly = $false
    $languageInput.Enabled = $true
    $autoButton.Enabled = [bool]$script:token
    $stopButton.Enabled = $false
    $pairButton.Enabled = $true
    $statusLabel.Text = 'توقفت القراءة.'
    $detailLabel.Text = ''
}
function Start-SelectedCapture([string]$mode) {
    if ($addressInput.Text.Trim() -ne $script:tvAddress) {
        $statusLabel.Text = 'اربط سكن من جديد إذا تغيّر عنوان التلفزيون.'
        return
    }
    Stop-Reading
    $script:pickWindow = [IntPtr]::Zero
    $script:pickMode = $mode
    Start-Reading
    $statusLabel.Text = 'اضغط داخل نافذة اللعبة في Remote Play لتبدأ.'
}

$autoButton.add_Click({
    Start-SelectedCapture 'dialogue'
    if ($script:readingActive) { $form.WindowState = 'Minimized' }
})
$stopButton.add_Click({
    Stop-Reading
    try { Save-Connection } catch { $detailLabel.Text = $_.Exception.Message }
})
$form.add_FormClosing({
    $script:readingActive = $false
    $timer.Stop()
})
foreach ($setting in @($languageInput,$fontInput,$sizeInput,$toneInput)) {
    $setting.add_SelectedIndexChanged({ try { Save-Connection } catch { $statusLabel.Text = $_.Exception.Message } })
}
$form.add_Shown({
    if (-not (Test-Path -LiteralPath $configPath)) { return }
    try {
        $saved = Import-Clixml -LiteralPath $configPath
        $script:tvAddress = Get-PrivateAddress $saved.Address
        $addressInput.Text = $script:tvAddress
        $languageInput.SelectedIndex = $saved.Language
        $fontInput.SelectedIndex = $saved.Font
        $sizeInput.SelectedIndex = $saved.Size
        $toneInput.SelectedIndex = $saved.Tone
        $script:token = [Net.NetworkCredential]::new('', $saved.Token).Password
        Stop-Reading
        $statusLabel.Text = 'التلفزيون مربوط. اضغط «حوار اللعبة · أسفل المنتصف».'
        if ($saved.Mode -in @('whole', 'region', 'selection', 'dialogue')) {
            $script:pickMode = 'dialogue'
            Start-Reading
            $statusLabel.Text = 'تستأنف قراءة الحوار أسفل المنتصف عند ظهور Remote Play.'
        }
    } catch { $statusLabel.Text = 'أدخل رمز اللابتوب لربط سكن من جديد.' }
})
try { [void]$form.ShowDialog() }
catch [System.Management.Automation.PipelineStoppedException] {}
finally {
    Stop-LocalReader
    $timer.Dispose()
    $form.Dispose()
    $uiFont.Dispose()
    if ($script:seen) { Clear-GameTranslation }
}
