@echo off
cd /d "%~dp0"
if exist "%LOCALAPPDATA%\SakanReader\venv\Scripts\python.exe" goto ready
py -3.11 -V >nul 2>&1
if errorlevel 1 winget install --id Python.Python.3.11 -e --scope user
set "BASEPY=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
if exist "%BASEPY%" goto direct
py -3.11 -m venv "%LOCALAPPDATA%\SakanReader\venv" || goto failed
goto ready
:direct
"%BASEPY%" -m venv "%LOCALAPPDATA%\SakanReader\venv" || goto failed
:ready
set "PY=%LOCALAPPDATA%\SakanReader\venv\Scripts\python.exe"
"%PY%" -m pip install "rapidocr-onnxruntime==1.4.4" "ctranslate2>=4.5,<5" "sentencepiece>=0.2,<0.3" "numpy<2" "opencv-python==4.11.0.86" "subword-nmt==0.3.8" "sacremoses==0.1.1" || goto failed
"%PY%" live_reader.py --setup || goto failed
start "" wscript.exe "%~dp0Open-Sakan.vbs"
exit /b 0
:failed
echo Setup failed. Check Python 3.11 x64 and the internet connection.
pause
exit /b 1
