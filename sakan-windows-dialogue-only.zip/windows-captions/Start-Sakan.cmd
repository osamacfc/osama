@echo off
start "" wscript.exe "%~dp0Open-Sakan.vbs"
