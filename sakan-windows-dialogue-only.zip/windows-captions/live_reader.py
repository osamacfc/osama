"""Local OCR/translation worker. Only its parent process receives the results."""
import base64
import contextlib
import functools
import json
import re
import sys
import os
import hashlib
import shutil
import tempfile
import urllib.request
import zipfile
from pathlib import Path

MODELS = {
    "en_ar": ("translate-en_ar-1_0", "e2a6e84337f7ebbb55f9dc61dcba3a861c0d786ae5a46fa198fd8d6473f5c775"),
    "es_en": ("translate-es_en-1_9", "c54df2b62fceaf54a3ce5d97db6bf56efd7940063329f6778f4212d2acb370d4"),
}
ROOT = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "SakanReader" / "models"


MODEL_BASE = "https://raw.githubusercontent.com/osamacfc/osama/sakan-download-20261021-33448f/"
MODEL_PARTS = {'translate-en_ar-1_0': ['translate-en_ar-1_0-part1.bin', 'translate-en_ar-1_0-part2.bin'], 'translate-es_en-1_9': ['translate-es_en-1_9-part1.bin', 'translate-es_en-1_9-part2.bin', 'translate-es_en-1_9-part3.bin', 'translate-es_en-1_9-part4.bin', 'translate-es_en-1_9-part5.bin']}


def install_models():
    ROOT.mkdir(parents=True, exist_ok=True)
    for pair, (name, checksum) in MODELS.items():
        if (ROOT / pair / "model" / "model.bin").is_file():
            continue
        with tempfile.TemporaryDirectory(dir=ROOT) as temp:
            archive = Path(__file__).parent / "models" / (name + ".argosmodel")
            if not archive.is_file():
                archive = Path(temp) / "model.zip"
                with archive.open("wb") as output:
                    for part in MODEL_PARTS[name]:
                        print("Downloading " + part + "...", flush=True)
                        with urllib.request.urlopen(MODEL_BASE + part, timeout=90) as response:
                            shutil.copyfileobj(response, output)
            print("Installing " + name + "...", flush=True)
            if hashlib.sha256(archive.read_bytes()).hexdigest() != checksum:
                raise ValueError("Model integrity check failed: " + name)
            with zipfile.ZipFile(archive) as pack:
                pack.extractall(temp)
            folder = next(Path(temp).glob("*/metadata.json")).parent
            folder.rename(ROOT / pair)


@functools.lru_cache(maxsize=2)
def engine(pair):
    import ctranslate2
    from sentencepiece import SentencePieceProcessor
    folder = ROOT / pair
    model = ctranslate2.Translator(str(folder / "model"), device="cpu", compute_type="float32" if pair == "es_en" else "int8", intra_threads=2)
    if pair == "en_ar":
        tokenizer = SentencePieceProcessor(model_file=str(folder / "sentencepiece.model"))
        return model, lambda text: tokenizer.encode(text, out_type=str), tokenizer.decode
    from subword_nmt.apply_bpe import BPE
    from sacremoses import MosesTokenizer, MosesDetokenizer
    with open(folder / "bpe.model", encoding="utf8") as codes:
        bpe = BPE(codes)
    tokenizer, detokenizer = MosesTokenizer(lang="es"), MosesDetokenizer(lang="en")
    return model, lambda text: bpe.process_line(tokenizer.tokenize(text, return_str=True)).split(), lambda parts: detokenizer.detokenize(" ".join(parts).replace("@@ ", "").split())


def translate_text(text, pair):
    model, encode, decode = engine(pair)
    tokens = model.translate_batch([encode(text)], beam_size=2)[0].hypotheses[0]
    return decode(tokens)


def read_dialogue(reader, band):
    """The capture process supplies only the bottom-center subtitle strip."""
    items, _ = reader(band)
    height, width = band.shape[:2]
    lines = []
    for pts, value, score in sorted(items or [], key=lambda item: min(p[1] for p in item[0])):
        if score < .55 or not re.search(r'[A-Za-zÀ-ÿ]', value) or re.search(r'[\u0600-\u06ff]', value):
            continue
        xs, ys = zip(*pts)
        mid = (min(ys) + max(ys)) / 2
        size = max(ys) - min(ys)
        if size <= 0:
            continue
        if not lines or abs(mid - lines[-1][0]) > size * .62:
            lines.append((mid, []))
        lines[-1][1].append((min(xs), max(xs), size, value))
    selected = []
    for mid, fragments in lines:
        # Keep edge HUD labels separate even when aligned with the subtitle.
        groups = []
        for fragment in sorted(fragments):
            if not groups or fragment[0] - groups[-1][-1][1] > fragment[2] * 2:
                groups.append([])
            groups[-1].append(fragment)
        for group in groups:
            center = (group[0][0] + group[-1][1]) / (2 * width)
            if .32 <= center <= .68:
                selected.append((mid, max(f[2] for f in group), ' '.join(f[3] for f in group)))
    if not selected:
        return [], len(items or [])
    # Start at the most recent (lowest) subtitle and keep adjacent wrapped lines.
    paragraph = [selected[-1]]
    for above in reversed(selected[:-1]):
        if paragraph[0][0] - above[0] > 1.9 * max(above[1], paragraph[0][1]):
            break
        paragraph.insert(0, above)
    text = ' '.join(line[2] for line in paragraph)
    return [dict(source=text, left=.15, right=.85, top=.93, bottom=.97)], len(items or [])


def serve():
    import onnxruntime
    onnxruntime.disable_telemetry_events()
    import cv2
    import numpy as np
    from rapidocr_onnxruntime import RapidOCR
    terms = json.loads(Path(__file__).with_name("game_terms.json").read_text("utf8"))
    reader = RapidOCR(intra_op_num_threads=2, inter_op_num_threads=1)
    @functools.lru_cache(maxsize=512)
    def arabic(value, language):
        known = terms.get(value) or terms.get(value.lower().replace('’', chr(39)).rstrip('.!?'))
        if known:
            return known
        if language == 'en':
            value = re.sub(r"(?i)\b(don't|doesn't|didn't) just (disappear|vanish)(?=\s*[,!?.]|$)",
                           r"\1 \2 for no reason", value)
            # In descriptions of a person this construction is an insult.
            value = re.sub(r"(?i)\b(was|is|being) a dick\b", r"\1 a jerk", value)
            value = re.sub(r"(?i)\b(was|is) our dick\b", r"\1 our jerk", value)
            expansions = {'u':'you','ur':'your','lmk':'let me know','dnt':"don’t",'wya':'where are you'}
            value = re.sub(r'(?i)\b(in|to|from) VC\b', r'\1 Vice City', value)
            value = re.sub(r'(?i)\b(hey|hi) Lu\b', r'\1 Lucia', value)
            value = re.sub(r'\b(?:u|ur|lmk|dnt|wya)\b', lambda m: expansions[m[0].lower()], value, flags=re.I)
        if language == 'en':
            value = re.sub(r"(?i)\bhow\s+'?bout\b", "how about", value)
            value = re.sub(r"(?i)\b(?:i\s+|l)?dunno\b", "I don't know", value)
            value = re.sub(r"(?i)\by['’]?know\b", "you know", value)
            value = re.sub(r"^(Cal|Jason|Lucia|Donnie|Mattia)\s+(?=[A-Z])", r"\1: ", value)
        speaker = re.match(r"^([A-Za-zÀ-ÿ][A-Za-zÀ-ÿ ’'-]{0,24}):\s*(.+)$", value)
        prefix = ""
        if speaker:
            name, value = speaker.groups()
            names = {"cal":"كال", "jason":"جيسون", "lucia":"لوسيا", "donnie":"دونّي", "mattia":"ماتّيا"}
            prefix = names.get(name.lower(), name) + ": "
        value = re.sub(r"([.!?])(?=[A-Z])", r"\1 ", value)
        if language == 'es':
            value = translate_text(value, 'es_en')
        # Short follow-up questions often disappear when decoded with the preceding sentence.
        clauses = re.split(r"(?<=[!?])\s+|(?<=[a-z]\.)\s+(?=[A-Za-z])", value)
        result = ' '.join(translate_text(clause, 'en_ar') for clause in clauses)
        return prefix + result if re.search(r'[\u0621-\u064a]', result) else ''
    for line in sys.stdin:
        try:
            request = json.loads(line)
            frame = cv2.imdecode(np.frombuffer(base64.b64decode(request['image']), np.uint8), cv2.IMREAD_COLOR)
            h,w = frame.shape[:2]
            rows, detected = read_dialogue(reader, frame)
            for row in rows:
                row['arabic'] = arabic(row['source'], request['language'])
                # TV 4.33 identifies dialogue by a role prefix when placing the overlay.
                # Only the Arabic field is rendered. Keep the prefix out of the translator.
                row['source'] = 'Dialogue: ' + row['source']
            response = {'rows':[r for r in rows if r['arabic']], 'detected':detected, 'readable':len(rows), 'width':w, 'height':h}
        except Exception as error:
            response = {'error':type(error).__name__}
        print(json.dumps(response), file=sys.__stdout__, flush=True)


if __name__ == '__main__':
    if '--setup' in sys.argv:
        install_models()
    else:
        with contextlib.redirect_stdout(sys.stderr):
            serve()
