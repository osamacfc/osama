﻿#requires -Version 5.1
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
Add-Type -ReferencedAssemblies 'System.Drawing' -TypeDefinition @'
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
public static class SakanGameCapture {
    [StructLayout(LayoutKind.Sequential)]
    private struct Rect { public int Left, Top, Right, Bottom; }
    [StructLayout(LayoutKind.Sequential)]
    private struct Point { public int X, Y; }

    [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
    [DllImport("user32.dll")] static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
    public static void EnablePhysicalPixels() {
        try {
            if (SetThreadDpiAwarenessContext(new IntPtr(-4)) != IntPtr.Zero) return;
        } catch (EntryPointNotFoundException) {}
        SetProcessDPIAware();
    }
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] static extern IntPtr GetShellWindow();
    delegate bool WindowVisitor(IntPtr window, IntPtr state);
    [DllImport("user32.dll")] static extern bool EnumWindows(WindowVisitor visit, IntPtr state);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr window);
    public static IntPtr FindSelectedWindow(Rectangle selection, int excludedOwner) {
        IntPtr chosen = IntPtr.Zero;
        IntPtr shell = GetShellWindow();
        var center = new System.Drawing.Point(selection.X + selection.Width / 2, selection.Y + selection.Height / 2);
        EnumWindows((window, state) => {
            if (window == shell || !IsWindowVisible(window) || WindowOwner(window) == excludedOwner
                || !ClientArea(window).Contains(center)) return true;
            chosen = window;
            return false;
        }, IntPtr.Zero);
        return chosen;
    }
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr window, out int processId);
    public static int WindowOwner(IntPtr window) {
        int processId;
        GetWindowThreadProcessId(window, out processId);
        return processId;
    }
    [DllImport("user32.dll")] static extern bool IsIconic(IntPtr window);
    [DllImport("user32.dll")] static extern bool GetClientRect(IntPtr window, out Rect rect);
    [DllImport("user32.dll")] static extern bool ClientToScreen(IntPtr window, ref Point point);

    public static Rectangle ClientArea(IntPtr window) {
        if (window == IntPtr.Zero || IsIconic(window)) return Rectangle.Empty;
        Rect rect;
        var origin = new Point();
        if (!GetClientRect(window, out rect) || !ClientToScreen(window, ref origin)) return Rectangle.Empty;
        int width = rect.Right, height = rect.Bottom;
        if (width < 160 || height < 90) return Rectangle.Empty;
        return new Rectangle(origin.X, origin.Y, width, height);
    }

    public static Rectangle VideoArea(IntPtr window) {
        Rectangle client = ClientArea(window);
        if (client.IsEmpty) return client;
        int videoWidth = Math.Min(client.Width, client.Height * 16 / 9);
        int videoHeight = Math.Min(client.Height, client.Width * 9 / 16);
        return new Rectangle(client.X + (client.Width - videoWidth) / 2, client.Y + (client.Height - videoHeight) / 2,
                videoWidth, videoHeight);
    }

    public static Rectangle CaptureCanvas(Rectangle client, Rectangle video, Rectangle selection) {
        return video.Contains(selection) ? video : client;
    }

    public static byte[] DemoJpeg(bool spanish) {
        using (var image = new Bitmap(960, 540, PixelFormat.Format24bppRgb))
        using (var graphics = Graphics.FromImage(image))
        using (var font = new Font("Arial", 32f, FontStyle.Bold))
        using (var stream = new MemoryStream()) {
            graphics.Clear(Color.FromArgb(20, 37, 55));
            graphics.DrawString(spanish ? "Ajustes" : "Settings", font, Brushes.White, 95, 100);
            graphics.DrawString(spanish ? "Velocidad de movimiento" : "Movement Speed", font, Brushes.White, 95, 205);
            graphics.DrawString(spanish ? "Te espero en el puente." : "I'll wait for you at the bridge.", font, Brushes.White, 95, 405);
            image.Save(stream, ImageFormat.Jpeg);
            return stream.ToArray();
        }
    }

    public static Bitmap Snapshot(Rectangle area) {
        var image = new Bitmap(area.Width, area.Height, PixelFormat.Format24bppRgb);
        try {
            using (var graphics = Graphics.FromImage(image))
                graphics.CopyFromScreen(area.X, area.Y, 0, 0, area.Size, CopyPixelOperation.SourceCopy);
            return image;
        } catch {
            image.Dispose();
            throw;
        }
    }

    public static Rectangle MapSelection(Rectangle source, Size view, Rectangle selection) {
        selection = Rectangle.Intersect(selection, new Rectangle(System.Drawing.Point.Empty, view));
        if (selection.Width == 0 || selection.Height == 0) return Rectangle.Empty;
        return Rectangle.FromLTRB(
            source.X + (int)Math.Floor((double)selection.Left * source.Width / view.Width),
            source.Y + (int)Math.Floor((double)selection.Top * source.Height / view.Height),
            source.X + (int)Math.Ceiling((double)selection.Right * source.Width / view.Width),
            source.Y + (int)Math.Ceiling((double)selection.Bottom * source.Height / view.Height));
    }

    public sealed class Frame {
        public byte[] Upload { get; set; }
        public byte[] Preview { get; set; }
    }

    public static Frame CaptureFrame(Rectangle area, Rectangle selection) {
        var region = new Rectangle(selection.X - area.X, selection.Y - area.Y, selection.Width, selection.Height);
        using (var full = Snapshot(area)) {
            if (selection == area) {
                byte[] upload = Encode(full, 1800);
                return new Frame { Upload = upload, Preview = upload };
            }
            using (var masked = new Bitmap(full.Width, full.Height, PixelFormat.Format24bppRgb)) {
                using (var graphics = Graphics.FromImage(masked)) {
                    graphics.Clear(Color.Black);
                    graphics.DrawImage(full, region, region, GraphicsUnit.Pixel);
                }
                byte[] upload = Encode(masked, 1800);
                using (var graphics = Graphics.FromImage(full))
                using (var border = new Pen(Color.Gold, Math.Max(2, full.Width / 500)))
                    graphics.DrawRectangle(border, region);
                return new Frame { Upload = upload, Preview = Encode(full, 1200) };
            }
        }
    }

    static byte[] Encode(Bitmap image, int limit) {
        double scale = Math.Min(1.0, (double)limit / Math.Max(image.Width, image.Height));
        using (var scaled = new Bitmap(image, (int)(image.Width * scale), (int)(image.Height * scale)))
        using (var stream = new MemoryStream())
        using (var encoder = new EncoderParameters(1)) {
            var codec = Array.Find(ImageCodecInfo.GetImageEncoders(), item => item.FormatID == ImageFormat.Jpeg.Guid);
            foreach (long quality in new long[] { 82, 62, 42 }) {
                stream.SetLength(0);
                encoder.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, quality);
                try {
                    scaled.Save(stream, codec, encoder);
                } finally {
                    encoder.Param[0].Dispose();
                    encoder.Param[0] = null;
                }
                if (stream.Length <= 590000) return stream.ToArray();
            }
            throw new InvalidOperationException("The game image is too large.");
        }
    }
}
'@
[SakanGameCapture]::EnablePhysicalPixels()
[System.Windows.Forms.Application]::SetUnhandledExceptionMode(
    [System.Windows.Forms.UnhandledExceptionMode]::ThrowException)

function Get-PrivateAddress([string]$address) {
    if ($address -notmatch '^\d{1,3}(?:\.\d{1,3}){3}$') { throw 'أدخل عنوان التلفزيون المحلي.' }
    [ipaddress]$ip = [ipaddress]::None
    if (-not [ipaddress]::TryParse($address, [ref]$ip) -or $address -ne $ip.ToString()) {
        throw 'أدخل عنوان التلفزيون المحلي.'
    }
    $number = $ip.GetAddressBytes()
    if ($number[0] -ne 10 -and
        -not ($number[0] -eq 172 -and $number[1] -ge 16 -and $number[1] -le 31) -and
        -not ($number[0] -eq 192 -and $number[1] -eq 168)) { throw 'استخدم عنوانًا من شبكة البيت.' }
    return $ip.ToString()
}

function Invoke-Sakan([string]$path, [hashtable]$body) {
    $headers = @{}
    if ($path -ne '/pair') { $headers.Authorization = "Bearer $($script:token)" }
    $json = ConvertTo-Json -InputObject $body -Compress
    $reply = Invoke-RestMethod -Method Post -Uri "http://$($script:tvAddress):8787$path" -Headers $headers `
        -ContentType 'application/json' -Body ([Text.Encoding]::UTF8.GetBytes($json)) -TimeoutSec 3 -MaximumRedirection 0
    if ($reply.ok -eq $false) { throw $reply.message }
    return $reply
}

function Submit-GameFrame([byte[]]$jpeg, [string]$language, [string]$font, [string]$size, [string]$tone) {
    $headers = @{
        Authorization = "Bearer $($script:token)"
        'X-Sakan-Language' = $language
        'X-Sakan-Font' = $font
        'X-Sakan-Size' = $size
        'X-Sakan-Tone' = $tone
    }
    $reply = Invoke-RestMethod -Method Post -Uri "http://$($script:tvAddress):8787/game-frame" -Headers $headers `
        -ContentType 'image/jpeg' -Body $jpeg -TimeoutSec 4 -MaximumRedirection 0
    if ($reply.ok -eq $false) { throw $reply.message }
    return $reply
}

$form = New-Object System.Windows.Forms.Form -Property @{
    Text = 'ترجمة اللعب · سكن'; StartPosition = 'CenterScreen'; Size = '460,553'
    FormBorderStyle = 'FixedDialog'; MaximizeBox = $false
}
$uiFont = New-Object System.Drawing.Font('Segoe UI', 10)
$form.Font = $uiFont
function New-Control($type, $text, $left, $top, $width, $height) {
    $control = New-Object "System.Windows.Forms.$type" -Property @{
        Text = $text; Left = $left; Top = $top; Width = $width; Height = $height
    }
    $form.Controls.Add($control)
    return $control
}
function New-Choice($label, $top, $choices, $index) {
    [void](New-Control Label $label 20 $top 135 25)
    $box = New-Control ComboBox '' 165 $top 230 26
    $box.DropDownStyle = 'DropDownList'
    $box.Items.AddRange($choices)
    $box.SelectedIndex = $index
    return $box
}

[void](New-Control Label 'عنوان التلفزيون' 20 20 135 25)
$addressInput = New-Control TextBox '192.168.8.28' 165 20 230 26
[void](New-Control Label 'رمز اللابتوب' 20 57 135 25)
$codeInput = New-Control TextBox '' 165 57 115 26
$codeInput.MaxLength = 6
$pairButton = New-Control Button 'ربط التلفزيون' 290 54 105 32
$languageInput = New-Choice 'لغة النص' 94 @('الإنجليزية', 'الإسبانية') 0
$fontInput = New-Choice 'أسلوب الخط' 130 @('عادي', 'عريض', 'مضغوط', 'تقليدي') 1
$sizeInput = New-Choice 'حجم الخط' 166 @('صغير', 'متوسط', 'كبير', 'كبير جدًا') 1
$toneInput = New-Choice 'لون النص' 202 @('أبيض', 'ذهبي') 0
$startButton = New-Control Button 'حدد منطقة النص وابدأ' 20 245 245 37
$stopButton = New-Control Button 'إيقاف' 280 245 115 37
$autoButton = New-Control Button 'اقرأ صورة اللعبة كاملة' 20 290 375 32
$startButton.Enabled = $false
$autoButton.Enabled = $false
$stopButton.Enabled = $false
$testButton = New-Control Button 'اختبار الترجمة على التلفزيون' 20 331 375 32
$testButton.Enabled = $false
$previewButton = New-Control Button 'معاينة آخر لقطة من اللعبة' 20 371 375 32
$previewButton.Enabled = $false
$statusLabel = New-Control Label 'افتح ريموت الجوال في سكن على التلفزيون وخذ رمز اللابتوب.' 20 413 380 44
$detailLabel = New-Control Label '' 20 462 380 44
$script:token = ''
$script:tvAddress = ''
$script:job = ''
$script:testJob = ''
$script:seen = $false
$script:windowKey = ''
$script:nextCaptureAt = 0L
$script:retryAt = 0L
$script:readingActive = $false
$script:selectedWindow = [IntPtr]::Zero
$script:selectedOwner = 0
$script:selectedClient = [System.Drawing.Rectangle]::Empty
$script:selectedCanvas = [System.Drawing.Rectangle]::Empty
$script:selectedArea = [System.Drawing.Rectangle]::Empty
$script:lastFrame = $null
$readingClock = [Diagnostics.Stopwatch]::StartNew()
$windowSettleMs = 350
$frameIntervalMs = 650
$configPath = Join-Path $env:LOCALAPPDATA 'Sakan\positioned-captions.xml'
$timer = New-Object System.Windows.Forms.Timer -Property @{ Interval = 150 }

function Save-Connection {
    if (-not $script:token -or $addressInput.Text.Trim() -ne $script:tvAddress) { return }
    $null = New-Item -ItemType Directory -Force (Split-Path $configPath)
    $settings = [pscustomobject]@{
        Address = $script:tvAddress
        Token = ConvertTo-SecureString $script:token -AsPlainText -Force
        Language = $languageInput.SelectedIndex
        Font = $fontInput.SelectedIndex
        Size = $sizeInput.SelectedIndex
        Tone = $toneInput.SelectedIndex
    }
    $settings | Export-Clixml -LiteralPath "$configPath.tmp"
    if ([IO.File]::Exists($configPath)) {
        [IO.File]::Replace("$configPath.tmp", $configPath, [NullString]::Value)
    }
    else { [IO.File]::Move("$configPath.tmp", $configPath) }
}

function Select-GameArea([bool]$wholeWindow) {
    $bounds = [System.Windows.Forms.Screen]::FromControl($form).Bounds
    $form.WindowState = 'Minimized'
    Start-Sleep -Milliseconds $windowSettleMs
    $snapshot = [SakanGameCapture]::Snapshot($bounds)
    try {
        $selection = @{ start = $null; area = $null; screenArea = $null; source = $bounds; whole = $wholeWindow }
        $overlay = New-Object System.Windows.Forms.Form -Property @{
            FormBorderStyle = 'None'; Bounds = $bounds; TopMost = $true
            StartPosition = 'Manual'; BackColor = 'Black'; BackgroundImage = $snapshot
            BackgroundImageLayout = 'Stretch'; Cursor = 'Cross'
            KeyPreview = $true; ShowInTaskbar = $false; Tag = $selection
        }
        $instruction = New-Object System.Windows.Forms.Label -Property @{
            Text = $(if ($wholeWindow) { 'اضغط داخل صورة اللعبة لاختيار النافذة كاملة. Esc للإلغاء.' }
                else { 'اسحب حول النص على هذه اللقطة الثابتة. Esc للإلغاء.' })
            AutoSize = $true; Top = 8; Left = 8; BackColor = 'Black'; ForeColor = 'White'; Font = $uiFont
        }
        $overlay.Controls.Add($instruction)
        $overlay.add_KeyDown({ param($sender, $e) if ($e.KeyCode -eq 'Escape') { $sender.Close() } })
        $overlay.add_MouseDown({
            param($sender, $e)
            if ($e.Button -ne 'Left') { return }
            $sender.Tag.start = $e.Location
            $sender.Capture = $true
        })
        $overlay.add_MouseMove({
            param($sender, $e)
            $selection = $sender.Tag
            if ($null -eq $selection.start -or $selection.whole) { return }
            $selection.area = [Drawing.Rectangle]::FromLTRB(
                [Math]::Min($e.X, $selection.start.X), [Math]::Min($e.Y, $selection.start.Y),
                [Math]::Max($e.X, $selection.start.X), [Math]::Max($e.Y, $selection.start.Y))
            $sender.Invalidate()
        })
        $overlay.add_Paint({
            param($sender, $e)
            if ($null -ne $sender.Tag.area) { $e.Graphics.DrawRectangle([Drawing.Pens]::Yellow, $sender.Tag.area) }
        })
        $overlay.add_MouseUp({
            param($sender, $e)
            $selection = $sender.Tag
            if ($e.Button -ne 'Left' -or $null -eq $selection.start) { return }
            $rectangle = if ($selection.whole) { [Drawing.Rectangle]::new($e.X, $e.Y, 1, 1) }
                else { [Drawing.Rectangle]::FromLTRB(
                    [Math]::Min($e.X, $selection.start.X), [Math]::Min($e.Y, $selection.start.Y),
                    [Math]::Max($e.X, $selection.start.X), [Math]::Max($e.Y, $selection.start.Y)) }
            $mapped = [SakanGameCapture]::MapSelection($selection.source, $sender.ClientSize, $rectangle)
            if ($selection.whole -or ($mapped.Width -ge 24 -and $mapped.Height -ge 12)) {
                $selection.screenArea = $mapped
            }
            $sender.Capture = $false
            $sender.Close()
        })
        try {
            [void]$overlay.ShowDialog()
            return $selection.screenArea
        } finally { $overlay.Dispose() }
    } finally { $snapshot.Dispose() }
}

function Start-Reading {
    if (-not $script:token) { return }
    $script:job = ''
    $script:windowKey = ''
    $script:retryAt = 0L
    $script:readingActive = $true
    $script:lastFrame = $null
    $previewButton.Enabled = $false
    $startButton.Enabled = $false
    $autoButton.Enabled = $false
    $stopButton.Enabled = $true
    $testButton.Enabled = $true
    $pairButton.Enabled = $false
    $addressInput.ReadOnly = $true
    $statusLabel.Text = 'خلّ نافذة اللعبة ظاهرة على اللابتوب.'
    $detailLabel.Text = 'بانتظار أول لقطة من اللعبة.'
    $form.WindowState = 'Minimized'
    $timer.Start()
}

$pairButton.add_Click({
    try {
        $script:tvAddress = Get-PrivateAddress $addressInput.Text.Trim()
        if ($codeInput.Text -notmatch '^[0-9]{6}$') { throw 'أدخل رمز اللابتوب من ستة أرقام.' }
        $cap = Invoke-RestMethod -Uri "http://$($script:tvAddress):8787/game-frame" -TimeoutSec 3 -MaximumRedirection 0
        if (-not $cap.positionedCaptions) { throw 'حدّث سكن على التلفزيون إلى 4.27.' }
        $reply = Invoke-Sakan '/pair' @{code = $codeInput.Text; device = 'laptop'}
        if (-not $reply.token -or $reply.device -ne 'laptop') { throw 'تعذّر ربط اللابتوب. استخدم الرمز المخصص له.' }
        $script:token = $reply.token
        $codeInput.Clear()
        Stop-Reading
        $statusLabel.Text = 'تم الربط. اضغط «حدد منطقة النص وابدأ».'
        try { Save-Connection } catch { $statusLabel.Text = 'تم الربط. تعذّر حفظ الاقتران على ويندوز.' }
    } catch {
        $script:token = ''
        $startButton.Enabled = $false
        $autoButton.Enabled = $false
        $testButton.Enabled = $false
        $statusLabel.Text = $_.Exception.Message
    }
})

function Clear-GameTranslation {
    try { Invoke-Sakan '/game-frame/clear' @{} | Out-Null } catch {}
    $script:seen = $false
    $script:job = ''
}

function Submit-SelectedStyle([byte[]]$image) {
    Submit-GameFrame $image @('en','es')[$languageInput.SelectedIndex] `
        @('regular','bold','compact','serif')[$fontInput.SelectedIndex] `
        @('18','24','30','38')[$sizeInput.SelectedIndex] @('white','gold')[$toneInput.SelectedIndex]
}

$timer.add_Tick({
    if (-not $script:readingActive -or $readingClock.ElapsedMilliseconds -lt $script:retryAt) { return }
    $timer.Stop()
    try {
        if ($script:testJob) {
            $result = Invoke-Sakan '/game-frame/status' @{id = $script:testJob}
            $detailLabel.Text = $result.message
            if ($result.done) {
                $script:testJob = ''
                $script:seen = $true
                $script:readingActive = $false
                $testButton.Enabled = $true
                $startButton.Enabled = $true
                $autoButton.Enabled = $true
                $pairButton.Enabled = $true
                $statusLabel.Text = 'انتهى الاختبار. اضغط بدء القراءة للرجوع للعبة.'
            }
            return
        }
        $window = [SakanGameCapture]::GetForegroundWindow()
        if ($window -ne $script:selectedWindow -or [SakanGameCapture]::WindowOwner($window) -ne $script:selectedOwner) {
            if ($script:seen) { Clear-GameTranslation }
            $script:windowKey = ''
            $statusLabel.Text = 'خلّ نافذة اللعبة اللي اخترتها في واجهة اللابتوب لاستئناف القراءة.'
            return
        }
        $client = [SakanGameCapture]::ClientArea($window)
        if (-not $client.Equals($script:selectedClient)) {
            Stop-Reading
            $statusLabel.Text = 'تغيّر مكان نافذة اللعبة أو حجمها. حددها مرة ثانية.'
            return
        }
        $area = $script:selectedCanvas
        $key = "$window/$area"
        if ($key -ne $script:windowKey) {
            if ($script:seen) { Clear-GameTranslation }
            $script:windowKey = $key
            $script:nextCaptureAt = $readingClock.ElapsedMilliseconds + $windowSettleMs
            return
        }
        if ($script:job) {
            $result = Invoke-Sakan '/game-frame/status' @{id = $script:job}
            if ($result.done) { $detailLabel.Text = $result.message }
            if (-not $result.done) {
                $statusLabel.Text = $result.message
                return
            }
            $script:job = ''
        }
        if ($readingClock.ElapsedMilliseconds -lt $script:nextCaptureAt) { return }
        if ([SakanGameCapture]::GetForegroundWindow() -ne $window -or
                -not $client.Equals([SakanGameCapture]::ClientArea($window))) { return }
        $script:nextCaptureAt = $readingClock.ElapsedMilliseconds + $frameIntervalMs
        $script:seen = $true
        $frame = [SakanGameCapture]::CaptureFrame($area, $script:selectedArea)
        $script:lastFrame = $frame.Preview
        $previewButton.Enabled = $true
        $statusLabel.Text = 'تم التقاط لقطة من اللعبة. جارٍ إرسالها للتلفزيون.'
        $result = Submit-SelectedStyle $frame.Upload
        $script:job = $result.id
        $statusLabel.Text = 'صورة Remote Play وصلت إلى سكن.'
    } catch [System.Management.Automation.PipelineStoppedException] {
        $script:readingActive = $false
        $form.Close()
    } catch {
        $script:job = ''
        $script:retryAt = $readingClock.ElapsedMilliseconds + 3000
        $detailLabel.Text = $_.Exception.Message
        if ($script:testJob) {
            $script:testJob = ''
            $script:readingActive = $false
            $testButton.Enabled = $true
            $startButton.Enabled = $true
            $autoButton.Enabled = $true
            $pairButton.Enabled = $true
            $statusLabel.Text = 'تعذّر إكمال الاختبار.'
        }
        if ($_.Exception.Response -and [int]$_.Exception.Response.StatusCode -eq 401) {
            Stop-Reading
            $script:token = ''
            Remove-Item -LiteralPath $configPath -ErrorAction SilentlyContinue
            $startButton.Enabled = $false
            $autoButton.Enabled = $false
            $testButton.Enabled = $false
            $form.WindowState = 'Normal'
            $statusLabel.Text = 'انتهى الاقتران. أدخل رمز اللابتوب من التلفزيون.'
        }
    } finally {
        if ($script:readingActive -and -not $form.IsDisposed) { $timer.Start() }
    }
})

function Stop-Reading {
    $script:readingActive = $false
    $timer.Stop()
    if ($script:seen -or $script:testJob) { Clear-GameTranslation }
    $script:testJob = ''
    $addressInput.ReadOnly = $false
    $startButton.Enabled = [bool]$script:token
    $autoButton.Enabled = [bool]$script:token
    $testButton.Enabled = [bool]$script:token
    $stopButton.Enabled = $false
    $pairButton.Enabled = $true
    $statusLabel.Text = 'توقفت القراءة.'
    $detailLabel.Text = ''
}
function Start-SelectedCapture([bool]$wholeWindow) {
    if ($addressInput.Text.Trim() -ne $script:tvAddress) {
        $statusLabel.Text = 'اربط سكن من جديد إذا تغيّر عنوان التلفزيون.'
        return
    }
    Stop-Reading
    try {
        $picked = Select-GameArea $wholeWindow
        if ($null -ne $picked -and -not $picked.IsEmpty) {
            $window = [SakanGameCapture]::FindSelectedWindow($picked, $PID)
            $client = [SakanGameCapture]::ClientArea($window)
            $video = [SakanGameCapture]::VideoArea($window)
            $crop = if ($wholeWindow) { $client } else { [Drawing.Rectangle]::Intersect($client, $picked) }
            $canvas = [SakanGameCapture]::CaptureCanvas($client, $video, $crop)
            if ($crop.Width -ge 24 -and $crop.Height -ge 12 -and
                    [System.Windows.Forms.SystemInformation]::VirtualScreen.Contains($canvas)) {
                $script:selectedWindow = $window
                $script:selectedOwner = [SakanGameCapture]::WindowOwner($window)
                $script:selectedClient = $client
                $script:selectedCanvas = $canvas
                $script:selectedArea = $crop
                Start-Reading
                return
            }
            $statusLabel.Text = 'خلّ نافذة اللعبة ظاهرة بالكامل خلف سكن واختر من داخل صورتها.'
        } else {
            $statusLabel.Text = 'اختيار منطقة اللعبة أُلغي. تقدر تبدأ تحديدًا جديدًا.'
        }
    } catch {
        $detailLabel.Text = $_.Exception.Message
    }
    $form.WindowState = 'Normal'
}

$startButton.add_Click({ Start-SelectedCapture $false })
$autoButton.add_Click({ Start-SelectedCapture $true })
$testButton.add_Click({
    Stop-Reading
    try {
        $script:retryAt = 0L
        $image = [SakanGameCapture]::DemoJpeg($languageInput.SelectedIndex -eq 1)
        $result = Submit-SelectedStyle $image
        $script:testJob = $result.id
        $statusLabel.Text = 'جارٍ اختبار الترجمة. راقب التلفزيون.'
        $detailLabel.Text = $result.message
        $testButton.Enabled = $false
        $startButton.Enabled = $false
        $autoButton.Enabled = $false
        $stopButton.Enabled = $true
        $pairButton.Enabled = $false
        $script:readingActive = $true
        $timer.Start()
    } catch {
        $detailLabel.Text = $_.Exception.Message
    }
})
$stopButton.add_Click({ Stop-Reading })
$previewButton.add_Click({
    if ($null -eq $script:lastFrame) { return }
    $bytes = [IO.MemoryStream]::new([byte[]]$script:lastFrame)
    $image = $null
    $preview = $null
    try {
        $image = [Drawing.Image]::FromStream($bytes)
        $preview = New-Object Windows.Forms.Form -Property @{
            Text = 'آخر لقطة من اللعبة'; StartPosition = 'CenterParent'; Size = '900,560'
        }
        $picture = New-Object Windows.Forms.PictureBox -Property @{ Dock = 'Fill'; SizeMode = 'Zoom'; Image = $image }
        $preview.Controls.Add($picture)
        [void]$preview.ShowDialog($form)
    } finally {
        if ($null -ne $preview) { $preview.Dispose() }
        if ($null -ne $image) { $image.Dispose() }
        $bytes.Dispose()
    }
})
$form.add_FormClosing({
    $script:readingActive = $false
    $timer.Stop()
})
foreach ($setting in @($languageInput,$fontInput,$sizeInput,$toneInput)) {
    $setting.add_SelectedIndexChanged({ try { Save-Connection } catch { $statusLabel.Text = $_.Exception.Message } })
}
$form.add_Shown({
    if (-not (Test-Path -LiteralPath $configPath)) { return }
    try {
        $saved = Import-Clixml -LiteralPath $configPath
        $script:tvAddress = Get-PrivateAddress $saved.Address
        $addressInput.Text = $script:tvAddress
        $languageInput.SelectedIndex = $saved.Language
        $fontInput.SelectedIndex = $saved.Font
        $sizeInput.SelectedIndex = $saved.Size
        $toneInput.SelectedIndex = $saved.Tone
        $script:token = [Net.NetworkCredential]::new('', $saved.Token).Password
        Stop-Reading
        $statusLabel.Text = 'التلفزيون مربوط. اضغط «حدد منطقة النص وابدأ».'
    } catch { $statusLabel.Text = 'أدخل رمز اللابتوب لربط سكن من جديد.' }
})
try { [void]$form.ShowDialog() }
catch [System.Management.Automation.PipelineStoppedException] {}
finally {
    $timer.Dispose()
    $form.Dispose()
    $uiFont.Dispose()
    if ($script:seen -or $script:testJob) { Clear-GameTranslation }
}
