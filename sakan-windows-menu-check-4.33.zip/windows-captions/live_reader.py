"""Local OCR/translation worker. Only its parent process receives the results."""
import base64
import contextlib
import functools
import json
import re
import sys
import os
import hashlib
import shutil
import tempfile
import urllib.request
import zipfile
from pathlib import Path

MODELS = {
    "en_ar": ("translate-en_ar-1_0", "e2a6e84337f7ebbb55f9dc61dcba3a861c0d786ae5a46fa198fd8d6473f5c775"),
    "es_en": ("translate-es_en-1_9", "c54df2b62fceaf54a3ce5d97db6bf56efd7940063329f6778f4212d2acb370d4"),
}
ROOT = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "SakanReader" / "models"


MODEL_BASE = "https://raw.githubusercontent.com/osamacfc/osama/sakan-download-20261021-33448f/"
MODEL_PARTS = {'translate-en_ar-1_0': ['translate-en_ar-1_0-part1.bin', 'translate-en_ar-1_0-part2.bin'], 'translate-es_en-1_9': ['translate-es_en-1_9-part1.bin', 'translate-es_en-1_9-part2.bin', 'translate-es_en-1_9-part3.bin', 'translate-es_en-1_9-part4.bin', 'translate-es_en-1_9-part5.bin']}


def install_models():
    ROOT.mkdir(parents=True, exist_ok=True)
    for pair, (name, checksum) in MODELS.items():
        if (ROOT / pair / "model" / "model.bin").is_file():
            continue
        with tempfile.TemporaryDirectory(dir=ROOT) as temp:
            archive = Path(__file__).parent / "models" / (name + ".argosmodel")
            if not archive.is_file():
                archive = Path(temp) / "model.zip"
                with archive.open("wb") as output:
                    for part in MODEL_PARTS[name]:
                        print("Downloading " + part + "...", flush=True)
                        with urllib.request.urlopen(MODEL_BASE + part, timeout=90) as response:
                            shutil.copyfileobj(response, output)
            print("Installing " + name + "...", flush=True)
            if hashlib.sha256(archive.read_bytes()).hexdigest() != checksum:
                raise ValueError("Model integrity check failed: " + name)
            with zipfile.ZipFile(archive) as pack:
                pack.extractall(temp)
            folder = next(Path(temp).glob("*/metadata.json")).parent
            folder.rename(ROOT / pair)


@functools.lru_cache(maxsize=2)
def engine(pair):
    import ctranslate2
    from sentencepiece import SentencePieceProcessor
    folder = ROOT / pair
    model = ctranslate2.Translator(str(folder / "model"), device="cpu", compute_type="float32" if pair == "es_en" else "int8", intra_threads=2)
    if pair == "en_ar":
        tokenizer = SentencePieceProcessor(model_file=str(folder / "sentencepiece.model"))
        return model, lambda text: tokenizer.encode(text, out_type=str), tokenizer.decode
    from subword_nmt.apply_bpe import BPE
    from sacremoses import MosesTokenizer, MosesDetokenizer
    with open(folder / "bpe.model", encoding="utf8") as codes:
        bpe = BPE(codes)
    tokenizer, detokenizer = MosesTokenizer(lang="es"), MosesDetokenizer(lang="en")
    return model, lambda text: bpe.process_line(tokenizer.tokenize(text, return_str=True)).split(), lambda parts: detokenizer.detokenize(" ".join(parts).replace("@@ ", "").split())


def translate_text(text, pair):
    model, encode, decode = engine(pair)
    tokens = model.translate_batch([encode(text)], beam_size=2)[0].hypotheses[0]
    return decode(tokens)


def group_lines(items, width, height, dialogue):
    rows = []
    for points, value, score in items:
        if score < .60 or not re.search(r'[A-Za-zÀ-ÿ]', value) or re.search(r'[\u0600-\u06ff]', value):
            continue
        xs, ys = zip(*[(float(x), float(y)) for x, y in points])
        rows.append(dict(source=value.strip(), left=max(0,min(xs)/width), right=min(1,max(xs)/width),
                         top=max(0,min(ys)/height), bottom=min(1,max(ys)/height)))
    rows.sort(key=lambda r: (r['top'], r['left']))
    result = []
    spoken = False
    for row in rows:
        center = (row['left'] + row['right']) / 2
        speaker = re.match(r"^[\w ’'-]{1,30}:\s*\S", row['source'])
        if result and spoken and not speaker:
            prev = result[-1]
            h = row['bottom'] - row['top']
            if (-h / 3 <= row['top'] - prev['bottom'] <= h and
                    abs(center - (prev['left'] + prev['right']) / 2) < .12):
                prev.update(source=prev['source'] + ' ' + row['source'], bottom=row['bottom'],
                            left=min(prev['left'],row['left']), right=max(prev['right'],row['right']))
                continue
        spoken = dialogue or bool(speaker and row['top'] > .7 and .25 < center < .75)
        result.append(row)
    return result[:32]


def serve():
    import onnxruntime
    onnxruntime.disable_telemetry_events()
    import cv2
    import numpy as np
    from rapidocr_onnxruntime import RapidOCR
    terms = json.loads(Path(__file__).with_name("game_terms.json").read_text("utf8"))
    reader = RapidOCR(intra_op_num_threads=2, inter_op_num_threads=1)
    @functools.lru_cache(maxsize=512)
    def arabic(value, language):
        known = terms.get(value) or terms.get(value.lower().replace('’', chr(39)).rstrip('.!?'))
        if known:
            return known
        if language == 'en':
            value = re.sub(r"(?i)\b(don't|doesn't|didn't) just (disappear|vanish)(?=\s*[,!?.]|$)",
                           r"\1 \2 for no reason", value)
            expansions = {'u':'you','ur':'your','lmk':'let me know','dnt':"don’t",'wya':'where are you'}
            value = re.sub(r'(?i)\b(in|to|from) VC\b', r'\1 Vice City', value)
            value = re.sub(r'(?i)\b(hey|hi) Lu\b', r'\1 Lucia', value)
            value = re.sub(r'\b(?:u|ur|lmk|dnt|wya)\b', lambda m: expansions[m[0].lower()], value, flags=re.I)
        speaker = re.match(r"^([A-Za-zÀ-ÿ][A-Za-zÀ-ÿ ’'-]{0,24}):\s*(.+)$", value)
        prefix = ""
        if speaker:
            name, value = speaker.groups()
            names = {"cal":"كال", "jason":"جيسون", "lucia":"لوسيا", "donnie":"دونّي", "mattia":"ماتّيا"}
            prefix = names.get(name.lower(), name) + ": "
        value = re.sub(r"([.!?])(?=[A-Z])", r"\1 ", value)
        if language == 'es':
            value = translate_text(value, 'es_en')
        result = translate_text(value, 'en_ar')
        return prefix + result if re.search(r'[\u0621-\u064a]', result) else ''
    for line in sys.stdin:
        try:
            request = json.loads(line)
            frame = cv2.imdecode(np.frombuffer(base64.b64decode(request['image']), np.uint8), cv2.IMREAD_COLOR)
            items, _ = reader(frame)
            h,w = frame.shape[:2]
            rows = group_lines(items or [], w, h, request['mode']=='region')
            # Full-screen downsampling can erase small menu labels. Retry both halves at native detail.
            detected = len(items or [])
            if not rows and request['mode'] == 'whole' and w >= 960:
                for left, right in [(0, w // 2), (w // 2, w)]:
                    strip, _ = reader(frame[:, left:right].copy())
                    detected += len(strip or [])
                    for row in group_lines(strip or [], right - left, h, False):
                        row['left'] = (left + row['left'] * (right - left)) / w
                        row['right'] = (left + row['right'] * (right - left)) / w
                        rows.append(row)
                rows = rows[:32]
            for row in rows:
                row['arabic'] = arabic(row['source'], request['language'])
            response = {'rows':[r for r in rows if r['arabic']], 'detected':detected, 'readable':len(rows), 'width':w, 'height':h}
        except Exception as error:
            response = {'error':type(error).__name__}
        print(json.dumps(response), file=sys.__stdout__, flush=True)


if __name__ == '__main__':
    if '--setup' in sys.argv:
        install_models()
    else:
        with contextlib.redirect_stdout(sys.stderr):
            serve()
