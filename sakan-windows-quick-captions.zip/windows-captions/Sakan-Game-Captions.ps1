﻿#requires -Version 5.1
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
Add-Type -ReferencedAssemblies 'System.Drawing' -TypeDefinition @'
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
public static class SakanGameCapture {
    [StructLayout(LayoutKind.Sequential)]
    private struct Rect { public int Left, Top, Right, Bottom; }
    [StructLayout(LayoutKind.Sequential)]
    private struct Point { public int X, Y; }

    [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] static extern bool IsIconic(IntPtr window);
    [DllImport("user32.dll")] static extern bool GetClientRect(IntPtr window, out Rect rect);
    [DllImport("user32.dll")] static extern bool ClientToScreen(IntPtr window, ref Point point);

    public static Rectangle VideoArea(IntPtr window) {
        if (window == IntPtr.Zero || GetForegroundWindow() != window || IsIconic(window)) return Rectangle.Empty;
        Rect rect;
        var origin = new Point();
        if (!GetClientRect(window, out rect) || !ClientToScreen(window, ref origin)) return Rectangle.Empty;
        int width = rect.Right, height = rect.Bottom;
        if (width < 320 || height < 180) return Rectangle.Empty;
        int videoWidth = Math.Min(width, height * 16 / 9), videoHeight = Math.Min(height, width * 9 / 16);
        return new Rectangle(origin.X + (width - videoWidth) / 2, origin.Y + (height - videoHeight) / 2,
                videoWidth, videoHeight);
    }

    public static byte[] Jpeg(Rectangle area) {
        using (var image = new Bitmap(area.Width, area.Height, PixelFormat.Format24bppRgb)) {
            using (var graphics = Graphics.FromImage(image)) {
                graphics.CopyFromScreen(area.Location, System.Drawing.Point.Empty, area.Size);
            }
            int width = Math.Min(area.Width, 1440);
            using (var scaled = new Bitmap(image, width, area.Height * width / area.Width))
            using (var stream = new MemoryStream())
            using (var encoder = new EncoderParameters(1)) {
                var codec = Array.Find(ImageCodecInfo.GetImageEncoders(), item => item.FormatID == ImageFormat.Jpeg.Guid);
                foreach (long quality in new long[] { 82, 62, 42 }) {
                    stream.SetLength(0);
                    encoder.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, quality);
                    try {
                        scaled.Save(stream, codec, encoder);
                    } finally {
                        encoder.Param[0].Dispose();
                        encoder.Param[0] = null;
                    }
                    if (stream.Length <= 590000) return stream.ToArray();
                }
                throw new InvalidOperationException("The game image is too large.");
            }
        }
    }
}
'@
[void][SakanGameCapture]::SetProcessDPIAware()

function Get-PrivateAddress([string]$address) {
    if ($address -notmatch '^\d{1,3}(?:\.\d{1,3}){3}$') { throw 'أدخل عنوان التلفزيون المحلي.' }
    [ipaddress]$ip = [ipaddress]::None
    if (-not [ipaddress]::TryParse($address, [ref]$ip) -or $address -ne $ip.ToString()) {
        throw 'أدخل عنوان التلفزيون المحلي.'
    }
    $number = $ip.GetAddressBytes()
    if ($number[0] -ne 10 -and
        -not ($number[0] -eq 172 -and $number[1] -ge 16 -and $number[1] -le 31) -and
        -not ($number[0] -eq 192 -and $number[1] -eq 168)) { throw 'استخدم عنوانًا من شبكة البيت.' }
    return $ip.ToString()
}

function Invoke-Sakan([string]$path, [hashtable]$body) {
    $headers = @{}
    if ($path -ne '/pair') { $headers.Authorization = "Bearer $($script:token)" }
    $json = ConvertTo-Json -InputObject $body -Compress
    $reply = Invoke-RestMethod -Method Post -Uri "http://$($script:tvAddress):8787$path" -Headers $headers `
        -ContentType 'application/json' -Body ([Text.Encoding]::UTF8.GetBytes($json)) -TimeoutSec 3 -MaximumRedirection 0
    if ($reply.ok -eq $false) { throw $reply.message }
    return $reply
}

function Submit-GameFrame([byte[]]$jpeg, [string]$language, [string]$font, [string]$size, [string]$tone) {
    $headers = @{
        Authorization = "Bearer $($script:token)"
        'X-Sakan-Language' = $language
        'X-Sakan-Font' = $font
        'X-Sakan-Size' = $size
        'X-Sakan-Tone' = $tone
    }
    $reply = Invoke-RestMethod -Method Post -Uri "http://$($script:tvAddress):8787/game-frame" -Headers $headers `
        -ContentType 'image/jpeg' -Body $jpeg -TimeoutSec 4 -MaximumRedirection 0
    if ($reply.ok -eq $false) { throw $reply.message }
    return $reply
}

$form = New-Object System.Windows.Forms.Form -Property @{
    Text = 'ترجمة اللعب · سكن'; StartPosition = 'CenterScreen'; Size = '460,390'
    FormBorderStyle = 'FixedDialog'; MaximizeBox = $false
}
$uiFont = New-Object System.Drawing.Font('Segoe UI', 10)
$form.Font = $uiFont
function New-Control($type, $text, $left, $top, $width, $height) {
    $control = New-Object "System.Windows.Forms.$type" -Property @{
        Text = $text; Left = $left; Top = $top; Width = $width; Height = $height
    }
    $form.Controls.Add($control)
    return $control
}
function New-Choice($label, $top, $choices, $index) {
    [void](New-Control Label $label 20 $top 135 25)
    $box = New-Control ComboBox '' 165 $top 230 26
    $box.DropDownStyle = 'DropDownList'
    $box.Items.AddRange($choices)
    $box.SelectedIndex = $index
    return $box
}

[void](New-Control Label 'عنوان التلفزيون' 20 20 135 25)
$addressInput = New-Control TextBox '192.168.8.28' 165 20 230 26
[void](New-Control Label 'رمز اللابتوب' 20 57 135 25)
$codeInput = New-Control TextBox '' 165 57 115 26
$codeInput.MaxLength = 6
$pairButton = New-Control Button 'ربط التلفزيون' 290 54 105 32
$languageInput = New-Choice 'لغة النص' 94 @('الإنجليزية', 'الإسبانية') 0
$fontInput = New-Choice 'أسلوب الخط' 130 @('عادي', 'عريض', 'مضغوط', 'تقليدي') 1
$sizeInput = New-Choice 'حجم الخط' 166 @('صغير', 'متوسط', 'كبير', 'كبير جدًا') 1
$toneInput = New-Choice 'لون النص' 202 @('أبيض', 'ذهبي') 0
$startButton = New-Control Button 'بدء القراءة التلقائية' 20 245 245 37
$stopButton = New-Control Button 'إيقاف' 280 245 115 37
$startButton.Enabled = $false
$stopButton.Enabled = $false
$statusLabel = New-Control Label 'افتح ريموت الجوال في سكن على التلفزيون وخذ رمز اللابتوب.' 20 295 380 50
$script:token = ''
$script:tvAddress = ''
$script:job = ''
$script:seen = $false
$script:windowKey = ''
$script:nextCaptureAt = 0L
$script:retryAt = 0L
$readingClock = [Diagnostics.Stopwatch]::StartNew()
$windowSettleMs = 350
$frameIntervalMs = 650
$configPath = Join-Path $env:LOCALAPPDATA 'Sakan\positioned-captions.xml'
$timer = New-Object System.Windows.Forms.Timer -Property @{ Interval = 150 }

function Save-Connection {
    if (-not $script:token -or $addressInput.Text.Trim() -ne $script:tvAddress) { return }
    $null = New-Item -ItemType Directory -Force (Split-Path $configPath)
    $settings = [pscustomobject]@{
        Address = $script:tvAddress
        Token = ConvertTo-SecureString $script:token -AsPlainText -Force
        Language = $languageInput.SelectedIndex
        Font = $fontInput.SelectedIndex
        Size = $sizeInput.SelectedIndex
        Tone = $toneInput.SelectedIndex
    }
    $settings | Export-Clixml -LiteralPath "$configPath.tmp"
    if ([IO.File]::Exists($configPath)) { [IO.File]::Replace("$configPath.tmp", $configPath, $null) }
    else { [IO.File]::Move("$configPath.tmp", $configPath) }
}

function Start-Reading {
    if (-not $script:token) { return }
    $script:job = ''
    $script:windowKey = ''
    $script:retryAt = 0L
    $startButton.Enabled = $false
    $stopButton.Enabled = $true
    $pairButton.Enabled = $false
    $addressInput.ReadOnly = $true
    $statusLabel.Text = 'بانتظار نافذة PS Remote Play. خلّها ظاهرة على اللابتوب.'
    $form.WindowState = 'Minimized'
    $timer.Start()
}

$pairButton.add_Click({
    try {
        $script:tvAddress = Get-PrivateAddress $addressInput.Text.Trim()
        if ($codeInput.Text -notmatch '^[0-9]{6}$') { throw 'أدخل رمز اللابتوب من ستة أرقام.' }
        $cap = Invoke-RestMethod -Uri "http://$($script:tvAddress):8787/game-frame" -TimeoutSec 3 -MaximumRedirection 0
        if (-not $cap.positionedCaptions) { throw 'حدّث سكن على التلفزيون إلى 4.27.' }
        $reply = Invoke-Sakan '/pair' @{code = $codeInput.Text; device = 'laptop'}
        if (-not $reply.token -or $reply.device -ne 'laptop') { throw 'تعذّر ربط اللابتوب. استخدم الرمز المخصص له.' }
        $script:token = $reply.token
        $codeInput.Clear()
        Start-Reading
        try { Save-Connection } catch { $statusLabel.Text = 'تم الربط. تعذّر حفظ الاقتران على ويندوز.' }
    } catch {
        $script:token = ''
        $startButton.Enabled = $false
        $statusLabel.Text = $_.Exception.Message
    }
})

function Clear-GameTranslation {
    try { Invoke-Sakan '/game-frame/clear' @{} | Out-Null } catch {}
    $script:seen = $false
    $script:job = ''
}

$timer.add_Tick({
    if ($readingClock.ElapsedMilliseconds -lt $script:retryAt) { return }
    try {
        $area = [System.Drawing.Rectangle]::Empty
        $window = [IntPtr]::Zero
        foreach ($process in @(Get-Process -Name RemotePlay -ErrorAction SilentlyContinue)) {
            $window = $process.MainWindowHandle
            $area = [SakanGameCapture]::VideoArea($window)
            if (-not $area.IsEmpty) { break }
        }
        if ($area.IsEmpty -or -not [System.Windows.Forms.SystemInformation]::VirtualScreen.Contains($area)) {
            if ($script:seen) { Clear-GameTranslation }
            $script:windowKey = ''
            $statusLabel.Text = 'افتح PS Remote Play وخَلّ نافذة اللعبة بواجهة اللابتوب.'
            return
        }
        $key = "$window/$area"
        if ($key -ne $script:windowKey) {
            if ($script:seen) { Clear-GameTranslation }
            $script:windowKey = $key
            $script:nextCaptureAt = $readingClock.ElapsedMilliseconds + $windowSettleMs
            return
        }
        if ($script:job) {
            $result = Invoke-Sakan '/game-frame/status' @{id = $script:job}
            $statusLabel.Text = $result.message
            if (-not $result.done) { return }
            $script:job = ''
        }
        if ($readingClock.ElapsedMilliseconds -lt $script:nextCaptureAt) { return }
        $script:nextCaptureAt = $readingClock.ElapsedMilliseconds + $frameIntervalMs
        $script:seen = $true
        $image = [SakanGameCapture]::Jpeg($area)
        $result = Submit-GameFrame $image @('en','es')[$languageInput.SelectedIndex] `
            @('regular','bold','compact','serif')[$fontInput.SelectedIndex] `
            @('18','24','30','38')[$sizeInput.SelectedIndex] @('white','gold')[$toneInput.SelectedIndex]
        $script:job = $result.id
    } catch {
        $script:job = ''
        $script:retryAt = $readingClock.ElapsedMilliseconds + 3000
        $statusLabel.Text = $_.Exception.Message
        if ($_.Exception.Response -and [int]$_.Exception.Response.StatusCode -eq 401) {
            Stop-Reading
            $script:token = ''
            Remove-Item -LiteralPath $configPath -ErrorAction SilentlyContinue
            $startButton.Enabled = $false
            $form.WindowState = 'Normal'
            $statusLabel.Text = 'انتهى الاقتران. أدخل رمز اللابتوب من التلفزيون.'
        }
    }
})

function Stop-Reading {
    $timer.Stop()
    if ($script:seen) { Clear-GameTranslation }
    $addressInput.ReadOnly = $false
    $startButton.Enabled = [bool]$script:token
    $stopButton.Enabled = $false
    $pairButton.Enabled = $true
    $statusLabel.Text = 'توقفت القراءة.'
}
$startButton.add_Click({
    if ($addressInput.Text.Trim() -eq $script:tvAddress) { Start-Reading }
    else { $statusLabel.Text = 'اربط سكن من جديد إذا تغيّر عنوان التلفزيون.' }
})
$stopButton.add_Click({ Stop-Reading })
$form.add_FormClosing({ Stop-Reading })
foreach ($setting in @($languageInput,$fontInput,$sizeInput,$toneInput)) {
    $setting.add_SelectedIndexChanged({ try { Save-Connection } catch { $statusLabel.Text = $_.Exception.Message } })
}
$form.add_Shown({
    if (-not (Test-Path -LiteralPath $configPath)) { return }
    try {
        $saved = Import-Clixml -LiteralPath $configPath
        $script:tvAddress = Get-PrivateAddress $saved.Address
        $addressInput.Text = $script:tvAddress
        $languageInput.SelectedIndex = $saved.Language
        $fontInput.SelectedIndex = $saved.Font
        $sizeInput.SelectedIndex = $saved.Size
        $toneInput.SelectedIndex = $saved.Tone
        $script:token = [Net.NetworkCredential]::new('', $saved.Token).Password
        Start-Reading
    } catch { $statusLabel.Text = 'أدخل رمز اللابتوب لربط سكن من جديد.' }
})
try { [void]$form.ShowDialog() }
finally { $timer.Dispose(); $uiFont.Dispose(); $form.Dispose() }
